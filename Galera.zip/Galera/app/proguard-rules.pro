# Правила R8 для Galera. Compose и Coil приносят свои consumer-правила.
-dontwarn org.jetbrains.annotations.**
