package com.galera.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.widget.RemoteViews
import com.galera.app.data.Editor
import com.galera.app.data.MediaRepository
import com.galera.app.data.Prefs
import kotlinx.coroutines.runBlocking

/** Виджет с одним фото: берёт случайное из избранного, а если его нет — из всей галереи. Скрытые не показывает. */
class PhotoWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        val pending = goAsync()
        Thread {
            try {
                val bitmap = pickBitmap(context)
                for (id in appWidgetIds) manager.updateAppWidget(id, build(context, bitmap))
            } finally {
                pending.finish()
            }
        }.start()
    }

    private fun pickBitmap(context: Context): Bitmap? = runCatching {
        val prefs = Prefs(context)
        val hidden = prefs.hidden()
        val favorites = prefs.favorites()
        val all = runBlocking { MediaRepository(context).loadPhotos() }
            .filter { !it.isVideo && it.id !in hidden }
        val pool = all.filter { it.id in favorites }.ifEmpty { all }
        val photo = pool.randomOrNull() ?: return null
        val raw = Editor.load(context, photo.uri, 512) ?: return null
        rounded(raw)
    }.getOrNull()

    private fun rounded(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
        val r = minOf(src.width, src.height) * 0.08f
        Canvas(out).drawRoundRect(RectF(0f, 0f, src.width.toFloat(), src.height.toFloat()), r, r, paint)
        return out
    }

    private fun build(context: Context, bitmap: Bitmap?): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_photo)
        if (bitmap != null) {
            views.setImageViewBitmap(R.id.widget_image, bitmap)
            views.setViewVisibility(R.id.widget_empty, View.GONE)
        } else {
            views.setViewVisibility(R.id.widget_empty, View.VISIBLE)
        }
        val open = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        views.setOnClickPendingIntent(R.id.widget_root, open)
        return views
    }
}
