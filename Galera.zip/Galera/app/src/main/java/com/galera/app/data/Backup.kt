package com.galera.app.data

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/** Имя и размер файла — по ним фото узнаётся после переустановки и на другом телефоне. */
class FileInfo(val name: String, val size: Long) {
    val key: String get() = "$name|$size"
}

/** Резервная копия коллекций, тегов, заметок, избранного и скрытых. Фото привязаны к файлам по «имя|размер». */
object Backup {

    fun fileInfos(context: Context): Map<Long, FileInfo> {
        val out = HashMap<Long, FileInfo>()
        fun scan(collection: Uri, video: Boolean) {
            runCatching {
                context.contentResolver.query(
                    collection,
                    arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE),
                    null, null, null,
                )?.use { c ->
                    while (c.moveToNext()) {
                        val raw = c.getLong(0)
                        val name = c.getString(1) ?: continue
                        out[if (video) raw + VIDEO_ID_OFFSET else raw] = FileInfo(name, c.getLong(2))
                    }
                }
            }
        }
        scan(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false)
        scan(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
        return out
    }

    fun export(
        albums: List<Album>,
        meta: Map<Long, PhotoMeta>,
        favorites: Set<Long>,
        hidden: Set<Long>,
        infos: Map<Long, FileInfo>,
    ): String {
        fun key(id: Long) = infos[id]?.key
        val root = JSONObject().put("app", "Galera").put("version", 1)
        root.put(
            "albums",
            JSONArray().also { arr ->
                albums.forEach { a ->
                    arr.put(
                        JSONObject()
                            .put("id", a.id)
                            .put("name", a.name)
                            .put("createdAt", a.createdAt)
                            .put("accent", a.accentIndex)
                            .put("cover", key(a.coverId) ?: JSONObject.NULL)
                            .put("items", JSONArray(a.photoIds.mapNotNull { key(it) })),
                    )
                }
            },
        )
        root.put(
            "meta",
            JSONArray().also { arr ->
                meta.forEach { (id, m) ->
                    val k = key(id) ?: return@forEach
                    arr.put(JSONObject().put("key", k).put("tags", JSONArray(m.tags)).put("note", m.note))
                }
            },
        )
        root.put("favorites", JSONArray(favorites.mapNotNull { key(it) }))
        root.put("hidden", JSONArray(hidden.mapNotNull { key(it) }))
        return root.toString()
    }

    class ParsedAlbum(val id: String, val name: String, val createdAt: Long, val accent: Int, val cover: String?, val items: List<String>)
    class Parsed(
        val albums: List<ParsedAlbum>,
        val meta: Map<String, PhotoMeta>,
        val favorites: Set<String>,
        val hidden: Set<String>,
    )

    fun parse(json: String): Parsed? = runCatching {
        val root = JSONObject(json)
        if (root.optString("app") != "Galera") return null
        fun strings(a: JSONArray?) = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }
        val albums = root.optJSONArray("albums")?.let { arr ->
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ParsedAlbum(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                    accent = o.optInt("accent", 0),
                    cover = if (o.isNull("cover")) null else o.optString("cover"),
                    items = strings(o.optJSONArray("items")),
                )
            }
        }.orEmpty()
        val meta = HashMap<String, PhotoMeta>()
        root.optJSONArray("meta")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                meta[o.getString("key")] = PhotoMeta(strings(o.optJSONArray("tags")), o.optString("note", ""))
            }
        }
        Parsed(albums, meta, strings(root.optJSONArray("favorites")).toSet(), strings(root.optJSONArray("hidden")).toSet())
    }.getOrNull()

    /** Точные дубликаты: одинаковый размер и одинаковое содержимое (SHA-1). */
    fun findDuplicates(
        context: Context,
        photos: List<Photo>,
        infos: Map<Long, FileInfo>,
        onProgress: (done: Int, total: Int) -> Unit,
    ): List<List<Photo>> {
        val bySize = photos.filter { (infos[it.id]?.size ?: 0L) > 0L }.groupBy { infos.getValue(it.id).size }
        val candidates = bySize.values.filter { it.size >= 2 }
        val total = candidates.sumOf { it.size }
        var done = 0
        val result = mutableListOf<List<Photo>>()
        for (group in candidates) {
            val byHash = HashMap<String, MutableList<Photo>>()
            for (p in group) {
                val h = runCatching { hash(context, p.uri) }.getOrNull()
                if (h != null) byHash.getOrPut(h) { mutableListOf() }.add(p)
                done++
                onProgress(done, total)
            }
            byHash.values.filter { it.size >= 2 }.forEach { result += it.sortedBy { p -> p.dateMillis } }
        }
        return result.sortedByDescending { it.size }
    }

    private fun hash(context: Context, uri: Uri): String {
        val md = MessageDigest.getInstance("SHA-1")
        context.contentResolver.openInputStream(uri)?.use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n <= 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
