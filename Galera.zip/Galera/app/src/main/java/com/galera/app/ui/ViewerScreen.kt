package com.galera.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import android.content.Context
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.galera.app.data.Photo
import com.galera.app.data.PhotoMeta
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ViewerScreen(
    photos: List<Photo>,
    startIndex: Int,
    favorites: Set<Long>,
    meta: Map<Long, PhotoMeta>,
    popularTags: List<String>,
    onBack: () -> Unit,
    onToggleFavorite: (Long) -> Unit,
    onAddTag: (Long, String) -> Unit,
    onRemoveTag: (Long, String) -> Unit,
    onNote: (Long, String) -> Unit,
    onRemove: ((Photo) -> Unit)? = null,
    onDeleteFromDevice: ((Photo) -> Unit)? = null,
) {
    if (photos.isEmpty()) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val pagerState = rememberPagerState(initialPage = startIndex.coerceIn(0, photos.lastIndex)) { photos.size }
    val stripState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var zoomed by remember { mutableStateOf(false) }
    var chrome by remember { mutableStateOf(true) }
    var playing by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var sheetOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current

    // «назад» сначала закрывает шторку с тегами
    BackHandler(enabled = sheetOpen) { sheetOpen = false }
    val view = LocalView.current

    // слайд-шоу: листаем каждые 3 секунды и не даём экрану погаснуть
    DisposableEffect(playing) {
        view.keepScreenOn = playing
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(playing, pagerState.currentPage) {
        if (playing && photos.size > 1) {
            delay(3000)
            pagerState.animateScrollToPage((pagerState.currentPage + 1) % photos.size)
        }
    }

    LaunchedEffect(pagerState.currentPage) { zoomed = false }
    LaunchedEffect(pagerState.currentPage, chrome) {
        if (chrome && photos.size > 1) {
            stripState.animateScrollToItem((pagerState.currentPage - 3).coerceAtLeast(0))
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(
            state = pagerState,
            userScrollEnabled = !zoomed,
            pageSpacing = 12.dp,
            key = { photos.getOrNull(it)?.id ?: it },
            modifier = Modifier.fillMaxSize(),
        ) { page ->
            val onTapPage = {
                if (playing) {
                    playing = false
                    chrome = true
                } else {
                    chrome = !chrome
                }
            }
            if (photos[page].isVideo) {
                VideoPage(
                    photo = photos[page],
                    isCurrent = pagerState.currentPage == page,
                    chrome = chrome,
                    onTap = onTapPage,
                )
            } else {
                ZoomableImage(
                    photo = photos[page],
                    isCurrent = pagerState.currentPage == page,
                    onZoomChange = { zoomed = it },
                    onTap = onTapPage,
                )
            }
        }

        AnimatedVisibility(
            visible = chrome,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.65f), Color.Transparent)))
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GlassButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад", tint = Color.White)
                }
                Text(
                    "${pagerState.currentPage + 1} / ${photos.size}",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f).padding(start = 16.dp),
                )
                val current = photos.getOrNull(pagerState.currentPage)
                val isFav = current != null && current.id in favorites
                GlassButton(onClick = { current?.let { onToggleFavorite(it.id) } }) {
                    Icon(
                        if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        "Избранное",
                        tint = if (isFav) Color(0xFFFF8A80) else Color.White,
                    )
                }
                Spacer(Modifier.size(8.dp))
                GlassButton(onClick = { current?.let { sharePhoto(context, it) } }) {
                    Icon(Icons.Rounded.Share, "Поделиться", tint = Color.White)
                }
                Spacer(Modifier.size(8.dp))
                Box {
                    GlassButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Rounded.MoreVert, "Ещё", tint = Color.White)
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Теги и заметка") },
                            onClick = {
                                menuOpen = false
                                sheetOpen = true
                            },
                        )
                        if (photos.size > 1) {
                            DropdownMenuItem(
                                text = { Text("Слайд-шоу") },
                                onClick = {
                                    menuOpen = false
                                    playing = true
                                    chrome = false
                                },
                            )
                        }
                        if (onRemove != null) {
                            DropdownMenuItem(
                                text = { Text("Убрать из коллекции") },
                                onClick = {
                                    menuOpen = false
                                    current?.let(onRemove)
                                },
                            )
                        }
                        if (onDeleteFromDevice != null) {
                            DropdownMenuItem(
                                text = { Text("Удалить с устройства") },
                                onClick = {
                                    menuOpen = false
                                    current?.let(onDeleteFromDevice)
                                },
                            )
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = chrome && !sheetOpen,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))))
                    .navigationBarsPadding()
                    .padding(top = 24.dp, bottom = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                val shown = photos.getOrNull(pagerState.currentPage)
                if (shown != null) {
                    MetaPill(
                        meta = meta[shown.id] ?: PhotoMeta(),
                        onClick = {
                            playing = false
                            sheetOpen = true
                        },
                    )
                }
                if (photos.size > 1) {
                    Spacer(Modifier.height(12.dp))
                    LazyRow(
                        state = stripState,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                    ) {
                        itemsIndexed(photos, key = { _, p -> p.id }) { index, photo ->
                            val isCurrent = index == pagerState.currentPage
                            val shape = RoundedCornerShape(10.dp)
                            PhotoImage(
                                photo.uri,
                                Modifier
                                    .size(width = 44.dp, height = 60.dp)
                                    .alpha(if (isCurrent) 1f else 0.5f)
                                    .clip(shape)
                                    .then(if (isCurrent) Modifier.border(2.dp, Color.White, shape) else Modifier)
                                    .clickable { scope.launch { pagerState.animateScrollToPage(index) } },
                                px = 160,
                            )
                        }
                    }
                }
            }
        }

        // затемнение под шторкой
        AnimatedVisibility(visible = sheetOpen, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.6f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        sheetOpen = false
                    },
            )
        }

        // шторка «Теги и заметка»
        AnimatedVisibility(
            visible = sheetOpen,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
        ) {
            val sheetPhoto = photos.getOrNull(pagerState.currentPage)
            if (sheetPhoto != null) {
                DetailsSheet(
                    photo = sheetPhoto,
                    meta = meta[sheetPhoto.id] ?: PhotoMeta(),
                    popularTags = popularTags,
                    onAddTag = { onAddTag(sheetPhoto.id, it) },
                    onRemoveTag = { onRemoveTag(sheetPhoto.id, it) },
                    onNote = { onNote(sheetPhoto.id, it) },
                    onClose = { sheetOpen = false },
                )
            }
        }
    }
}

@Composable
private fun ZoomableImage(
    photo: Photo,
    isCurrent: Boolean,
    onZoomChange: (Boolean) -> Unit,
    onTap: () -> Unit,
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }

    // при перелистывании сбрасываем зум соседних страниц
    LaunchedEffect(isCurrent) {
        if (!isCurrent) {
            scale = 1f
            offset = Offset.Zero
        }
    }
    LaunchedEffect(scale, isCurrent) {
        if (isCurrent) onZoomChange(scale > 1.01f)
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { box = it }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = {
                        if (scale > 1.05f) {
                            scale = 1f
                            offset = Offset.Zero
                        } else {
                            scale = 2.5f
                        }
                    },
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        // одним пальцем двигаем только при увеличении — иначе отдаём жест пейджеру
                        if (event.changes.size > 1 || scale > 1f) {
                            val newScale = (scale * event.calculateZoom()).coerceIn(1f, 5f)
                            val maxX = box.width * (newScale - 1f) / 2f
                            val maxY = box.height * (newScale - 1f) / 2f
                            val pan = event.calculatePan()
                            offset = Offset(
                                (offset.x + pan.x).coerceIn(-maxX, maxX),
                                (offset.y + pan.y).coerceIn(-maxY, maxY),
                            )
                            scale = newScale
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = offset.x
                translationY = offset.y
            },
        contentAlignment = Alignment.Center,
    ) {
        PhotoImage(photo.uri, Modifier.fillMaxSize(), px = 2048, contentScale = ContentScale.Fit)
    }
}

private fun sharePhoto(context: Context, photo: Photo) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = if (photo.isVideo) "video/*" else "image/*"
        putExtra(Intent.EXTRA_STREAM, photo.uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(send, "Поделиться").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
