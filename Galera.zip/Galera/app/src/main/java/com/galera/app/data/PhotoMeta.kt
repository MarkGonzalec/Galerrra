package com.galera.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Теги и заметка к одному фото. */
data class PhotoMeta(
    val tags: List<String> = emptyList(),
    val note: String = "",
) {
    val isEmpty: Boolean get() = tags.isEmpty() && note.isBlank()
}

/** Хранит теги и заметки в JSON-файле во внутренней памяти: {"<id фото>": {"tags": [...], "note": "..."}}. */
class MetaStore(context: Context) {

    private val file = File(context.filesDir, "meta.json")

    fun load(): Map<Long, PhotoMeta> {
        if (!file.exists()) return emptyMap()
        return runCatching {
            val root = JSONObject(file.readText())
            val result = HashMap<Long, PhotoMeta>()
            for (key in root.keys()) {
                val id = key.toLongOrNull() ?: continue
                val o = root.getJSONObject(key)
                val arr = o.optJSONArray("tags") ?: JSONArray()
                val meta = PhotoMeta(
                    tags = (0 until arr.length()).map { arr.getString(it) },
                    note = o.optString("note", ""),
                )
                if (!meta.isEmpty) result[id] = meta
            }
            result
        }.getOrDefault(emptyMap())
    }

    fun save(meta: Map<Long, PhotoMeta>) {
        val root = JSONObject()
        meta.forEach { (id, m) ->
            if (!m.isEmpty) {
                root.put(id.toString(), JSONObject().put("tags", JSONArray(m.tags)).put("note", m.note))
            }
        }
        // пишем во временный файл и переименовываем — файл не побьётся, если приложение закроют посреди записи
        runCatching {
            val tmp = File(file.parentFile, "meta.json.tmp")
            tmp.writeText(root.toString())
            if (!tmp.renameTo(file)) {
                file.writeText(root.toString())
                tmp.delete()
            }
        }
    }
}

/** Приводит ввод к виду тега: без «#», без лишних пробелов, не длиннее 24 символов. */
fun normalizeTag(raw: String): String =
    raw.trim().trimStart('#').trim().replace(Regex("\\s+"), " ").take(24)
