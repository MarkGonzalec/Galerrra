package com.galera.app.data

import android.app.ActivityManager
import android.content.Context

/** Режим экономии: 0 — авто (по устройству), 1 — всегда включён, 2 — всегда выключен. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("galera", Context.MODE_PRIVATE)

    var economy: Int
        get() = sp.getInt("economy", 0)
        set(value) = sp.edit().putInt("economy", value).apply()

    /** Вид списка коллекций: 0 — сетка, 1 — лента. */
    var albumLayout: Int
        get() = sp.getInt("albumLayout", 0)
        set(value) = sp.edit().putInt("albumLayout", value).apply()

    /** Тема: 0 — тёмная, 1 — светлая, 2 — как в системе. */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(value) = sp.edit().putInt("theme", value).apply()

    /** Колонок в сетках фото: 2–5. */
    var gridColumns: Int
        get() = sp.getInt("gridColumns", 3).coerceIn(2, 5)
        set(value) = sp.edit().putInt("gridColumns", value.coerceIn(2, 5)).apply()

    fun hidden(): Set<Long> =
        sp.getStringSet("hidden", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()

    fun saveHidden(ids: Set<Long>) {
        sp.edit().putStringSet("hidden", ids.map { it.toString() }.toSet()).apply()
    }

    private fun hash(pin: String, salt: String): String =
        java.security.MessageDigest.getInstance("SHA-256")
            .digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    val hasPin: Boolean get() = sp.getString("pinHash", null) != null

    fun setPin(pin: String) {
        val salt = java.util.UUID.randomUUID().toString()
        sp.edit().putString("pinSalt", salt).putString("pinHash", hash(pin, salt)).apply()
    }

    fun checkPin(pin: String): Boolean {
        val salt = sp.getString("pinSalt", null) ?: return false
        return hash(pin, salt) == sp.getString("pinHash", null)
    }

    fun favorites(): Set<Long> =
        sp.getStringSet("favorites", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()

    fun saveFavorites(ids: Set<Long>) {
        sp.edit().putStringSet("favorites", ids.map { it.toString() }.toSet()).apply()
    }
}

object Device {
    /** Слабое устройство: мало оперативной памяти, малый лимит кучи или мало ядер. */
    fun isLowEnd(context: Context): Boolean {
        val am = context.getSystemService(ActivityManager::class.java) ?: return false
        return am.isLowRamDevice ||
            am.memoryClass <= 192 ||
            Runtime.getRuntime().availableProcessors() <= 4
    }
}
