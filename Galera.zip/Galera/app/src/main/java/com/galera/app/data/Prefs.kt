package com.galera.app.data

import android.app.ActivityManager
import android.content.Context

/** Режим экономии: 0 — авто (по устройству), 1 — всегда включён, 2 — всегда выключен. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("galera", Context.MODE_PRIVATE)

    var economy: Int
        get() = sp.getInt("economy", 0)
        set(value) = sp.edit().putInt("economy", value).apply()

    /** Вид списка коллекций: 0 — сетка, 1 — лента. */
    var albumLayout: Int
        get() = sp.getInt("albumLayout", 0)
        set(value) = sp.edit().putInt("albumLayout", value).apply()

    fun favorites(): Set<Long> =
        sp.getStringSet("favorites", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()

    fun saveFavorites(ids: Set<Long>) {
        sp.edit().putStringSet("favorites", ids.map { it.toString() }.toSet()).apply()
    }
}

object Device {
    /** Слабое устройство: мало оперативной памяти, малый лимит кучи или мало ядер. */
    fun isLowEnd(context: Context): Boolean {
        val am = context.getSystemService(ActivityManager::class.java) ?: return false
        return am.isLowRamDevice ||
            am.memoryClass <= 192 ||
            Runtime.getRuntime().availableProcessors() <= 4
    }
}
