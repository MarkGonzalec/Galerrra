package com.galera.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Flip
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.galera.app.data.AspectNames
import com.galera.app.data.Edit
import com.galera.app.data.Editor
import com.galera.app.data.FilterNames
import com.galera.app.data.Photo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Простой редактор: поворот, отражение, обрезка по пропорциям, свет и цвет, фильтры. Сохраняет копию. */
@Composable
fun EditorScreen(
    photo: Photo,
    onClose: () -> Unit,
    onSaved: () -> Unit,
) {
    val context = LocalContext.current
    val low = LocalLowEnd.current
    val scope = rememberCoroutineScope()

    var edit by remember { mutableStateOf(Edit()) }
    var tab by remember { mutableIntStateOf(0) }
    var saving by remember { mutableStateOf(false) }

    val base: Bitmap? by produceState<Bitmap?>(null, photo.uri) {
        value = withContext(Dispatchers.IO) { Editor.load(context, photo.uri, if (low) 1200 else 1800) }
    }
    val changed = edit != Edit()

    fun doSave() {
        if (saving) return
        saving = true
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                val bmp = Editor.render(context, photo.uri, edit, if (low) 2560 else 4096)
                bmp != null && Editor.save(context, bmp) != null
            }
            saving = false
            if (ok) {
                Toast.makeText(context, "Сохранено копией в Pictures/Galera", Toast.LENGTH_SHORT).show()
                onSaved()
            } else {
                Toast.makeText(context, "Не удалось сохранить", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) doSave() else Toast.makeText(context, "Нужен доступ к памяти, чтобы сохранить", Toast.LENGTH_LONG).show()
    }
    fun startSave() {
        val needPerm = Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        if (needPerm) permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) else doSave()
    }

    BackHandler(enabled = changed && !saving) { onClose() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val bmp = base
        if (bmp == null) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
        } else {
            val rotated = remember(bmp, edit.rotation, edit.flipH) { Editor.transform(bmp, edit.rotation, edit.flipH) }
            val image = remember(rotated) { rotated.asImageBitmap() }
            val crop = Editor.cropRect(rotated.width, rotated.height, edit.aspect)
            val filter = remember(edit.brightness, edit.contrast, edit.saturation, edit.filter) {
                ColorFilter.colorMatrix(ColorMatrix(Editor.colorMatrix(edit).array))
            }
            Canvas(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(top = 64.dp, bottom = 250.dp, start = 12.dp, end = 12.dp),
            ) {
                val cw = crop.width().toFloat()
                val ch = crop.height().toFloat()
                val scale = minOf(size.width / cw, size.height / ch)
                val dw = (cw * scale).roundToInt().coerceAtLeast(1)
                val dh = (ch * scale).roundToInt().coerceAtLeast(1)
                drawImage(
                    image = image,
                    srcOffset = IntOffset(crop.left, crop.top),
                    srcSize = IntSize(crop.width(), crop.height()),
                    dstOffset = IntOffset(((size.width - dw) / 2).roundToInt(), ((size.height - dh) / 2).roundToInt()),
                    dstSize = IntSize(dw, dh),
                    colorFilter = filter,
                )
            }
        }

        // верхняя панель
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlassButton(onClick = { if (!saving) onClose() }) { Icon(Icons.Rounded.Close, "Закрыть", tint = Color.White) }
            Spacer(Modifier.weight(1f))
            if (changed) {
                SegmentPill(text = "Сбросить", selected = false, onClick = { edit = Edit() })
                Spacer(Modifier.width(8.dp))
            }
            SegmentPill(text = "Сохранить", selected = true, onClick = { if (base != null) startSave() })
        }

        // нижняя панель
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(GaleraPill)
                .navigationBarsPadding()
                .padding(top = 14.dp, bottom = 16.dp),
        ) {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Обрезка", "Свет", "Фильтры").forEachIndexed { i, t ->
                    SegmentPill(text = t, selected = tab == i, onClick = { tab = i })
                }
            }
            Spacer(Modifier.height(14.dp))
            Box(Modifier.height(130.dp)) {
                when (tab) {
                    0 -> Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            itemsIndexed(AspectNames) { i, name ->
                                SegmentPill(text = name, selected = edit.aspect == i, onClick = { edit = edit.copy(aspect = i) })
                            }
                        }
                        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SegmentPill(
                                text = "Повернуть",
                                selected = false,
                                icon = Icons.Rounded.RotateRight,
                                onClick = { edit = edit.copy(rotation = (edit.rotation + 1) % 4) },
                            )
                            SegmentPill(
                                text = "Отразить",
                                selected = false,
                                icon = Icons.Rounded.Flip,
                                onClick = { edit = edit.copy(flipH = !edit.flipH) },
                            )
                        }
                    }
                    1 -> Column(Modifier.padding(horizontal = 16.dp)) {
                        AdjustSlider("Яркость", edit.brightness, -1f..1f) { edit = edit.copy(brightness = it) }
                        AdjustSlider("Контраст", edit.contrast, 0.5f..1.5f) { edit = edit.copy(contrast = it) }
                        AdjustSlider("Насыщенность", edit.saturation, 0f..2f) { edit = edit.copy(saturation = it) }
                    }
                    else -> LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        itemsIndexed(FilterNames) { i, name ->
                            SegmentPill(text = name, selected = edit.filter == i, onClick = { edit = edit.copy(filter = i) })
                        }
                    }
                }
            }
        }

        if (saving) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color.White)
            }
        }
    }
}

@Composable
private fun AdjustSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(104.dp),
        )
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Color.White,
                inactiveTrackColor = Color.White.copy(alpha = 0.25f),
            ),
            modifier = Modifier.height(36.dp),
        )
    }
}
