package com.galera.app.data

import android.net.Uri

data class Photo(
    val id: Long,
    val uri: Uri,
    val dateMillis: Long,
    val isVideo: Boolean = false,
    val durationMs: Long = 0L,
    /** Папка на устройстве (Camera, Screenshots…). */
    val bucket: String = "",
)

/** Таблицы фото и видео в MediaStore нумеруются отдельно — сдвигаем id видео, чтобы не пересекались. */
const val VIDEO_ID_OFFSET = 1L shl 40

data class Album(
    val id: String,
    val name: String,
    val createdAt: Long,
    val accentIndex: Int,
    val photoIds: List<Long>,
    /** Фото-обложка (-1 — по умолчанию первое). */
    val coverId: Long = -1L,
)

/** Фото коллекции, обложка (если выбрана) — первой. Для плиток и рядов на главной. */
fun Album.coverFirst(byId: Map<Long, Photo>): List<Photo> {
    val list = photoIds.mapNotNull { byId[it] }
    val c = list.indexOfFirst { it.id == coverId }
    return if (c > 0) listOf(list[c]) + list.filterIndexed { i, _ -> i != c } else list
}
