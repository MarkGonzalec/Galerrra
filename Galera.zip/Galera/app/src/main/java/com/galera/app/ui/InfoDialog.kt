package com.galera.app.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.provider.OpenableColumns
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.exifinterface.media.ExifInterface
import com.galera.app.data.Photo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Сведения о файле: имя, размер, разрешение, дата, камера и параметры съёмки (если есть в EXIF). */
@Composable
fun InfoDialog(photo: Photo, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val rows by produceState<List<Pair<String, String>>>(emptyList(), photo.uri) {
        value = withContext(Dispatchers.IO) { readInfo(context, photo) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (photo.isVideo) "О видео" else "О фото") },
        text = {
            Column(
                Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (rows.isEmpty()) Text("Загрузка…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                rows.forEach { (k, v) ->
                    Row(Modifier.fillMaxWidth()) {
                        Text(k, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(110.dp))
                        Text(v, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(start = 4.dp))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } },
    )
}

private fun readInfo(context: Context, photo: Photo): List<Pair<String, String>> {
    val out = mutableListOf<Pair<String, String>>()
    val resolver = context.contentResolver
    runCatching {
        resolver.query(photo.uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                c.getString(0)?.let { out += "Имя" to it }
                val size = c.getLong(1)
                if (size > 0) out += "Размер" to formatSize(size)
            }
        }
    }
    out += "Дата" to SimpleDateFormat("d MMMM yyyy, HH:mm", Locale("ru")).format(Date(photo.dateMillis))
    if (photo.isVideo) {
        runCatching {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(context, photo.uri)
                val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                if (w != null && h != null) out += "Разрешение" to "$w × $h"
            } finally {
                r.release()
            }
        }
        if (photo.durationMs > 0) out += "Длительность" to formatDuration(photo.durationMs)
        return out
    }
    runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(photo.uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth > 0) {
            val mp = bounds.outWidth.toLong() * bounds.outHeight / 1_000_000.0
            out += "Разрешение" to "${bounds.outWidth} × ${bounds.outHeight} (%.1f Мп)".format(Locale.US, mp)
        }
    }
    runCatching {
        resolver.openInputStream(photo.uri)?.use { stream ->
            val exif = ExifInterface(stream)
            val camera = listOfNotNull(
                exif.getAttribute(ExifInterface.TAG_MAKE),
                exif.getAttribute(ExifInterface.TAG_MODEL),
            ).joinToString(" ").trim()
            if (camera.isNotEmpty()) out += "Камера" to camera
            exif.getAttribute(ExifInterface.TAG_F_NUMBER)?.toDoubleOrNull()?.let { out += "Диафрагма" to "f/%.1f".format(Locale.US, it) }
            exif.getAttribute(ExifInterface.TAG_EXPOSURE_TIME)?.toDoubleOrNull()?.let {
                out += "Выдержка" to if (it in 0.0001..0.99) "1/${(1 / it).toInt()} с" else "%.1f с".format(Locale.US, it)
            }
            exif.getAttribute(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY)?.let { out += "ISO" to it }
            exif.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, 0.0).takeIf { it > 0 }?.let {
                out += "Фокусное" to "%.0f мм".format(Locale.US, it)
            }
            exif.latLong?.let { out += "Место" to "%.5f, %.5f".format(Locale.US, it[0], it[1]) }
        }
    }
    return out
}

private fun formatSize(bytes: Long): String = when {
    bytes >= 1L shl 20 -> "%.1f МБ".format(Locale.US, bytes / 1048576.0)
    else -> "%d КБ".format(bytes / 1024)
}
