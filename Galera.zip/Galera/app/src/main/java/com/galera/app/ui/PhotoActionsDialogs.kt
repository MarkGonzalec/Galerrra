package com.galera.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.galera.app.data.Album

/** «В коллекцию»: выбрать существующую или создать новую из выбранных фото. */
@Composable
fun AddToAlbumDialog(
    albums: List<Album>,
    count: Int,
    onPick: (Album) -> Unit,
    onNew: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var creating by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (creating) "Новая коллекция" else "В коллекцию · $count") },
        text = {
            if (creating) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 40) name = it },
                    singleLine = true,
                    placeholder = { Text("Название") },
                )
            } else {
                LazyColumn(Modifier.heightIn(max = 340.dp)) {
                    item {
                        PickRow(title = "＋  Новая коллекция", subtitle = null, accent = null) { creating = true }
                    }
                    items(albums, key = { it.id }) { album ->
                        PickRow(
                            title = album.name,
                            subtitle = "${album.photoIds.size} фото",
                            accent = Accents[album.accentIndex % Accents.size],
                        ) { onPick(album) }
                    }
                }
            }
        },
        confirmButton = {
            if (creating) {
                TextButton(onClick = { onNew(name.trim().ifBlank { "Новая коллекция" }) }) { Text("Создать") }
            }
        },
        dismissButton = {
            TextButton(onClick = { if (creating) creating = false else onDismiss() }) {
                Text(if (creating) "Назад" else "Отмена")
            }
        },
    )
}

@Composable
private fun PickRow(
    title: String,
    subtitle: String?,
    accent: androidx.compose.ui.graphics.Color?,
    onClick: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clip(CircleShape).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (accent != null) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(accent))
            Spacer(Modifier.width(12.dp))
        }
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** «Тег» для нескольких фото: ввести новый или выбрать из часто используемых. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TagManyDialog(
    count: Int,
    popularTags: List<String>,
    onApply: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var tag by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Тег для $count фото") },
        text = {
            Column {
                OutlinedTextField(
                    value = tag,
                    onValueChange = { tag = it.take(24) },
                    singleLine = true,
                    placeholder = { Text("Например, отпуск") },
                    prefix = { Text("#") },
                    modifier = Modifier.fillMaxWidth(),
                )
                if (popularTags.isNotEmpty()) {
                    Spacer(Modifier.size(14.dp))
                    Text(
                        "Часто используете",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        popularTags.take(10).forEach { t -> TagChip(t, onClick = { onApply(t) }) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onApply(tag) }, enabled = tag.isNotBlank()) { Text("Добавить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}
