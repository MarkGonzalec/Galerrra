package com.galera.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.galera.app.data.Album
import com.galera.app.data.AlbumStore
import com.galera.app.data.Backup
import com.galera.app.data.MediaRepository
import com.galera.app.data.MetaStore
import com.galera.app.data.PhotoMeta
import com.galera.app.data.normalizeTag
import com.galera.app.data.Photo
import com.galera.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = MediaRepository(app)
    private val store = AlbumStore(app)
    private val prefs = Prefs(app)
    private val metaStore = MetaStore(app)

    private val _photos = MutableStateFlow<List<Photo>>(emptyList())

    /** Все фото, включая скрытые (нужно просмотру скрытой папки). */
    val allPhotos: StateFlow<List<Photo>> = _photos.asStateFlow()

    private val _hidden = MutableStateFlow(prefs.hidden())

    /** Видимые фото: скрытые из всех экранов убраны. */
    val photos: StateFlow<List<Photo>> = combine(_photos, _hidden) { p, h ->
        if (h.isEmpty()) p else p.filterNot { it.id in h }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val hiddenPhotos: StateFlow<List<Photo>> = combine(_photos, _hidden) { p, h ->
        if (h.isEmpty()) emptyList() else p.filter { it.id in h }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun hide(ids: Collection<Long>) {
        _hidden.value = _hidden.value + ids
        prefs.saveHidden(_hidden.value)
    }

    fun unhide(ids: Collection<Long>) {
        _hidden.value = _hidden.value - ids.toSet()
        prefs.saveHidden(_hidden.value)
    }

    fun hasPin(): Boolean = prefs.hasPin
    fun setPin(pin: String) = prefs.setPin(pin)
    fun checkPin(pin: String): Boolean = prefs.checkPin(pin)

    private val _albums = MutableStateFlow(store.load())
    val albums: StateFlow<List<Album>> = _albums.asStateFlow()

    private val _favorites = MutableStateFlow(prefs.favorites())
    val favorites: StateFlow<Set<Long>> = _favorites.asStateFlow()

    /** 0 — авто, 1 — экономичный режим включён, 2 — выключен. */
    private val _economy = MutableStateFlow(prefs.economy)
    val economy: StateFlow<Int> = _economy.asStateFlow()

    /** Теги и заметки по id фото. */
    private val _meta = MutableStateFlow(metaStore.load())
    val meta: StateFlow<Map<Long, PhotoMeta>> = _meta.asStateFlow()

    /** Список фото, открытый в просмотре из «Всех фото» (с учётом фильтров). */
    private val _viewerIds = MutableStateFlow<List<Long>>(emptyList())
    val viewerIds: StateFlow<List<Long>> = _viewerIds.asStateFlow()

    fun openList(ids: List<Long>) {
        _viewerIds.value = ids
    }

    fun addTag(photoId: Long, raw: String) {
        val tag = normalizeTag(raw)
        if (tag.isEmpty()) return
        updateMeta(photoId) { m ->
            if (m.tags.any { it.equals(tag, ignoreCase = true) }) m else m.copy(tags = m.tags + tag)
        }
    }

    fun removeTag(photoId: Long, tag: String) = updateMeta(photoId) { m ->
        m.copy(tags = m.tags.filterNot { it.equals(tag, ignoreCase = true) })
    }

    /** Добавляет тег сразу нескольким фото. */
    fun addTagToMany(photoIds: Collection<Long>, raw: String) {
        val tag = normalizeTag(raw)
        if (tag.isEmpty() || photoIds.isEmpty()) return
        val next = _meta.value.toMutableMap()
        photoIds.forEach { id ->
            val m = next[id] ?: PhotoMeta()
            if (m.tags.none { it.equals(tag, ignoreCase = true) }) next[id] = m.copy(tags = m.tags + tag)
        }
        _meta.value = next
        viewModelScope.launch(Dispatchers.IO) { metaStore.save(_meta.value) }
    }

    /** Добавляет (favorite = true) или убирает несколько фото из избранного. */
    fun setFavorite(photoIds: Collection<Long>, favorite: Boolean) {
        val current = _favorites.value
        _favorites.value = if (favorite) current + photoIds else current - photoIds.toSet()
        prefs.saveFavorites(_favorites.value)
    }

    fun setNote(photoId: Long, note: String) = updateMeta(photoId) { it.copy(note = note.trim()) }

    private fun updateMeta(photoId: Long, transform: (PhotoMeta) -> PhotoMeta) {
        val next = _meta.value.toMutableMap()
        val updated = transform(next[photoId] ?: PhotoMeta())
        if (updated.isEmpty) next.remove(photoId) else next[photoId] = updated
        _meta.value = next
        // пишем самое свежее состояние, чтобы быстрые подряд правки не перезаписали друг друга старой версией
        viewModelScope.launch(Dispatchers.IO) { metaStore.save(_meta.value) }
    }

    private val _trashed = MutableStateFlow<List<Photo>>(emptyList())
    val trashed: StateFlow<List<Photo>> = _trashed.asStateFlow()

    fun refreshTrash() {
        viewModelScope.launch { _trashed.value = repo.loadTrashed() }
    }

    // ───────── резервная копия ─────────

    suspend fun backupJson(): String = withContext(Dispatchers.IO) {
        val infos = Backup.fileInfos(getApplication())
        Backup.export(_albums.value, _meta.value, _favorites.value, _hidden.value, infos)
    }

    /** Добавляет данные из копии к текущим. Возвращает (коллекций, привязанных фото) или null, если файл не подошёл. */
    suspend fun restoreBackup(json: String): Pair<Int, Int>? = withContext(Dispatchers.IO) {
        val parsed = Backup.parse(json) ?: return@withContext null
        val infos = Backup.fileInfos(getApplication())
        val byKey = HashMap<String, Long>()
        infos.forEach { (id, info) -> byKey.putIfAbsent(info.key, id) }

        var matched = 0
        val albums = _albums.value.toMutableList()
        parsed.albums.forEach { pa ->
            val ids = pa.items.mapNotNull { byKey[it] }
            matched += ids.size
            val cover = pa.cover?.let { byKey[it] } ?: -1L
            val i = albums.indexOfFirst { it.id == pa.id }
            if (i >= 0) {
                albums[i] = albums[i].copy(photoIds = (albums[i].photoIds + ids).distinct())
            } else {
                albums += Album(pa.id, pa.name, pa.createdAt, pa.accent, ids, cover)
            }
        }
        _albums.value = albums
        store.save(albums)

        val meta = _meta.value.toMutableMap()
        parsed.meta.forEach { (key, m) ->
            val id = byKey[key] ?: return@forEach
            val old = meta[id]
            meta[id] = if (old == null) m else PhotoMeta(
                tags = (old.tags + m.tags.filter { t -> old.tags.none { it.equals(t, true) } }),
                note = old.note.ifBlank { m.note },
            )
        }
        _meta.value = meta
        metaStore.save(meta)

        _favorites.value = _favorites.value + parsed.favorites.mapNotNull { byKey[it] }
        prefs.saveFavorites(_favorites.value)
        _hidden.value = _hidden.value + parsed.hidden.mapNotNull { byKey[it] }
        prefs.saveHidden(_hidden.value)
        parsed.albums.size to matched
    }

    // ───────── дубликаты ─────────

    private val _dupRunning = MutableStateFlow(false)
    val dupRunning: StateFlow<Boolean> = _dupRunning.asStateFlow()
    private val _dupProgress = MutableStateFlow(0 to 0)
    val dupProgress: StateFlow<Pair<Int, Int>> = _dupProgress.asStateFlow()
    private val _dupGroups = MutableStateFlow<List<List<Photo>>?>(null)
    val dupGroups: StateFlow<List<List<Photo>>?> = _dupGroups.asStateFlow()

    fun scanDuplicates() {
        if (_dupRunning.value) return
        _dupRunning.value = true
        _dupProgress.value = 0 to 0
        viewModelScope.launch(Dispatchers.IO) {
            val infos = Backup.fileInfos(getApplication())
            val groups = Backup.findDuplicates(getApplication(), photos.value, infos) { d, t ->
                _dupProgress.value = d to t
            }
            _dupGroups.value = groups
            _dupRunning.value = false
        }
    }

    fun refresh() {
        viewModelScope.launch { _photos.value = repo.loadPhotos() }
    }

    private val _albumLayout = MutableStateFlow(prefs.albumLayout)
    val albumLayout: StateFlow<Int> = _albumLayout.asStateFlow()

    fun setAlbumLayout(layout: Int) {
        prefs.albumLayout = layout
        _albumLayout.value = layout
    }

    private val _theme = MutableStateFlow(prefs.theme)
    val theme: StateFlow<Int> = _theme.asStateFlow()

    fun setTheme(mode: Int) {
        prefs.theme = mode
        _theme.value = mode
    }

    private val _gridColumns = MutableStateFlow(prefs.gridColumns)
    val gridColumns: StateFlow<Int> = _gridColumns.asStateFlow()

    fun setGridColumns(n: Int) {
        prefs.gridColumns = n
        _gridColumns.value = n.coerceIn(2, 5)
    }

    fun setCover(albumId: String, photoId: Long) = modify(albumId) { it.copy(coverId = photoId) }

    fun setEconomy(mode: Int) {
        prefs.economy = mode
        _economy.value = mode
    }

    fun toggleFavorite(photoId: Long) {
        val current = _favorites.value
        _favorites.value = if (photoId in current) current - photoId else current + photoId
        prefs.saveFavorites(_favorites.value)
    }

    fun createAlbum(name: String, ids: List<Long>, accentIndex: Int): String {
        val album = Album(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            createdAt = System.currentTimeMillis(),
            accentIndex = accentIndex,
            photoIds = ids,
        )
        update { listOf(album) + it }
        return album.id
    }

    fun addPhotos(albumId: String, ids: List<Long>) = modify(albumId) {
        it.copy(photoIds = (it.photoIds + ids).distinct())
    }

    fun removePhoto(albumId: String, photoId: Long) = modify(albumId) {
        it.copy(photoIds = it.photoIds - photoId)
    }

    fun rename(albumId: String, name: String) = modify(albumId) {
        it.copy(name = name.trim().ifEmpty { it.name })
    }

    fun deleteAlbum(albumId: String) = update { list -> list.filterNot { it.id == albumId } }

    private fun modify(albumId: String, transform: (Album) -> Album) = update { list ->
        list.map { if (it.id == albumId) transform(it) else it }
    }

    private fun update(transform: (List<Album>) -> List<Album>) {
        val next = transform(_albums.value)
        _albums.value = next
        // запись на диск — не в главном потоке
        viewModelScope.launch(Dispatchers.IO) { store.save(_albums.value) }
    }
}
