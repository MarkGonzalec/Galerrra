package com.galera.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.galera.app.data.Album
import com.galera.app.data.AlbumStore
import com.galera.app.data.MediaRepository
import com.galera.app.data.Photo
import com.galera.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = MediaRepository(app)
    private val store = AlbumStore(app)
    private val prefs = Prefs(app)

    private val _photos = MutableStateFlow<List<Photo>>(emptyList())
    val photos: StateFlow<List<Photo>> = _photos.asStateFlow()

    private val _albums = MutableStateFlow(store.load())
    val albums: StateFlow<List<Album>> = _albums.asStateFlow()

    private val _favorites = MutableStateFlow(prefs.favorites())
    val favorites: StateFlow<Set<Long>> = _favorites.asStateFlow()

    /** 0 — авто, 1 — экономичный режим включён, 2 — выключен. */
    private val _economy = MutableStateFlow(prefs.economy)
    val economy: StateFlow<Int> = _economy.asStateFlow()

    fun refresh() {
        viewModelScope.launch { _photos.value = repo.loadPhotos() }
    }

    fun setEconomy(mode: Int) {
        prefs.economy = mode
        _economy.value = mode
    }

    fun toggleFavorite(photoId: Long) {
        val current = _favorites.value
        _favorites.value = if (photoId in current) current - photoId else current + photoId
        prefs.saveFavorites(_favorites.value)
    }

    fun createAlbum(name: String, ids: List<Long>, accentIndex: Int): String {
        val album = Album(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            createdAt = System.currentTimeMillis(),
            accentIndex = accentIndex,
            photoIds = ids,
        )
        update { listOf(album) + it }
        return album.id
    }

    fun addPhotos(albumId: String, ids: List<Long>) = modify(albumId) {
        it.copy(photoIds = (it.photoIds + ids).distinct())
    }

    fun removePhoto(albumId: String, photoId: Long) = modify(albumId) {
        it.copy(photoIds = it.photoIds - photoId)
    }

    fun rename(albumId: String, name: String) = modify(albumId) {
        it.copy(name = name.trim().ifEmpty { it.name })
    }

    fun deleteAlbum(albumId: String) = update { list -> list.filterNot { it.id == albumId } }

    private fun modify(albumId: String, transform: (Album) -> Album) = update { list ->
        list.map { if (it.id == albumId) transform(it) else it }
    }

    private fun update(transform: (List<Album>) -> List<Album>) {
        val next = transform(_albums.value)
        _albums.value = next
        // запись на диск — не в главном потоке
        viewModelScope.launch(Dispatchers.IO) { store.save(next) }
    }
}
