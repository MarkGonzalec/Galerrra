package com.galera.app.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaRepository(private val context: Context) {

    suspend fun loadPhotos(): List<Photo> = withContext(Dispatchers.IO) {
        val result = mutableListOf<Photo>()
        result += query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, video = false)
        result += query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, video = true)
        result.sortedByDescending { it.dateMillis }
    }

    /** Корзина системы (Android 11+): фото и видео, помеченные как удалённые. */
    suspend fun loadTrashed(): List<Photo> = withContext(Dispatchers.IO) {
        if (Build.VERSION.SDK_INT < 30) return@withContext emptyList()
        (query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, video = false, trashed = true) +
            query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, video = true, trashed = true))
            .sortedByDescending { it.dateMillis }
    }

    private fun query(collection: Uri, video: Boolean, trashed: Boolean = false): List<Photo> {
        val out = mutableListOf<Photo>()
        val projection = if (video) {
            arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DATE_TAKEN,
                MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            )
        } else {
            arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATE_TAKEN,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            )
        }
        try {
            val cursor = if (trashed && Build.VERSION.SDK_INT >= 30) {
                val args = Bundle().apply {
                    putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_ONLY)
                    putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "${MediaStore.MediaColumns.DATE_ADDED} DESC")
                }
                context.contentResolver.query(collection, projection, args, null)
            } else {
                context.contentResolver.query(
                    collection, projection, null, null,
                    "${MediaStore.MediaColumns.DATE_ADDED} DESC",
                )
            }
            cursor?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val takenCol = c.getColumnIndexOrThrow("datetaken")
                val addedCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val bucketCol = c.getColumnIndexOrThrow("bucket_display_name")
                val durCol = if (video) c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION) else -1
                while (c.moveToNext()) {
                    val rawId = c.getLong(idCol)
                    val taken = c.getLong(takenCol)
                    val added = c.getLong(addedCol) * 1000L
                    out += Photo(
                        id = if (video) rawId + VIDEO_ID_OFFSET else rawId,
                        uri = ContentUris.withAppendedId(collection, rawId),
                        dateMillis = if (taken > 0) taken else added,
                        isVideo = video,
                        durationMs = if (durCol >= 0) c.getLong(durCol) else 0L,
                        bucket = c.getString(bucketCol).orEmpty(),
                    )
                }
            }
        } catch (_: SecurityException) {
            // нет разрешения — пропускаем эту таблицу
        }
        return out
    }
}
