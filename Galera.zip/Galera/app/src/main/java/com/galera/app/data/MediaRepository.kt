package com.galera.app.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaRepository(private val context: Context) {

    suspend fun loadPhotos(): List<Photo> = withContext(Dispatchers.IO) {
        val result = mutableListOf<Photo>()
        result += query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, video = false)
        result += query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, video = true)
        result.sortedByDescending { it.dateMillis }
    }

    private fun query(collection: Uri, video: Boolean): List<Photo> {
        val out = mutableListOf<Photo>()
        val projection = if (video) {
            arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DATE_TAKEN,
                MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.DURATION,
            )
        } else {
            arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATE_TAKEN,
                MediaStore.Images.Media.DATE_ADDED,
            )
        }
        try {
            context.contentResolver.query(
                collection, projection, null, null,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC",
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val takenCol = c.getColumnIndexOrThrow("datetaken")
                val addedCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val durCol = if (video) c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION) else -1
                while (c.moveToNext()) {
                    val rawId = c.getLong(idCol)
                    val taken = c.getLong(takenCol)
                    val added = c.getLong(addedCol) * 1000L
                    out += Photo(
                        id = if (video) rawId + VIDEO_ID_OFFSET else rawId,
                        uri = ContentUris.withAppendedId(collection, rawId),
                        dateMillis = if (taken > 0) taken else added,
                        isVideo = video,
                        durationMs = if (durCol >= 0) c.getLong(durCol) else 0L,
                    )
                }
            }
        } catch (_: SecurityException) {
            // нет разрешения — пропускаем эту таблицу
        }
        return out
    }
}
