package com.galera.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsDialog(
    current: Int,
    onSelect: (Int) -> Unit,
    columns: Int,
    onColumns: (Int) -> Unit,
    theme: Int,
    onTheme: (Int) -> Unit,
    onTrash: (() -> Unit)?,
    onHidden: () -> Unit,
    onDuplicates: () -> Unit,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onDismiss: () -> Unit,
) {
    val options = listOf("Авто", "Включён", "Выключен")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Настройки") },
        text = {
            Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                if (onTrash != null) {
                    SettingsLink("Корзина", "Удалённые фото и видео — можно восстановить") { onDismiss(); onTrash() }
                }
                SettingsLink("Скрытая папка", "Фото под PIN-кодом") { onDismiss(); onHidden() }
                SettingsLink("Дубликаты", "Найти одинаковые файлы и убрать лишние") { onDismiss(); onDuplicates() }
                SettingsLink("Сохранить копию данных", "Коллекции, теги, заметки, избранное — в файл") { onDismiss(); onBackup() }
                SettingsLink("Восстановить из копии", "Добавить данные из сохранённого файла") { onDismiss(); onRestore() }
                Spacer(Modifier.height(14.dp))

                Text("Тема", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Тёмная", "Светлая", "Как в системе").forEachIndexed { i, label ->
                        SegmentPill(text = label, selected = theme == i, onClick = { onTheme(i) })
                    }
                }
                Spacer(Modifier.height(18.dp))

                Text("Размер сетки", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(2.dp))
                Text(
                    "Сколько фото в ряду. В самих сетках можно менять щипком двумя пальцами.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (2..5).forEach { n ->
                        SegmentPill(text = n.toString(), selected = columns == n, onClick = { onColumns(n) })
                    }
                }
                Spacer(Modifier.height(18.dp))

                Text("Экономичный режим", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(2.dp))
                Text(
                    "Меньше теней и анимаций, картинки декодируются легче. Для старых и слабых телефонов. " +
                        "«Авто» включает его сам, если устройство слабое.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                options.forEachIndexed { index, label ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(index) }.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = current == index, onClick = { onSelect(index) })
                        Text(label)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Кэш картинок обновится после перезапуска приложения.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Готово") } },
    )
}

@Composable
private fun SettingsLink(title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
