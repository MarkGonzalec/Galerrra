package com.galera.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.galera.app.data.Photo

/** Корзина: тап выбирает фото, внизу «Восстановить» и «Удалить навсегда» (системное подтверждение). */
@Composable
fun TrashScreen(
    photos: List<Photo>,
    columns: Int,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onRestore: (List<Photo>) -> Unit,
    onDeleteForever: (List<Photo>) -> Unit,
) {
    LaunchedEffect(Unit) { onRefresh() }
    val selected = remember { mutableListOf<Long>().toMutableStateList() }
    LaunchedEffect(photos) {
        val ids = photos.mapTo(HashSet()) { it.id }
        selected.removeAll { it !in ids }
    }
    val chosen = photos.filter { it.id in selected }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                GlassButton(onClick = onBack, size = 40.dp) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад", tint = LocalInk.current.ink, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (chosen.isEmpty()) "Корзина" else "Выбрано: ${chosen.size}", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Система хранит удалённое около 30 дней",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (photos.isNotEmpty()) {
                    SegmentPill(
                        text = if (chosen.size == photos.size) "Снять" else "Все",
                        selected = false,
                        onClick = {
                            if (chosen.size == photos.size) selected.clear()
                            else photos.forEach { if (it.id !in selected) selected.add(it.id) }
                        },
                    )
                }
            }
            if (photos.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Корзина пуста", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    contentPadding = PaddingValues(start = 3.dp, end = 3.dp, bottom = 130.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    items(photos, key = { it.id }) { photo ->
                        val on = photo.id in selected
                        Box(
                            Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { if (on) selected.remove(photo.id) else selected.add(photo.id) },
                        ) {
                            PhotoImage(photo.uri, Modifier.fillMaxSize(), px = 360)
                            if (photo.isVideo) VideoBadge(photo.durationMs, Modifier.align(Alignment.BottomStart).padding(5.dp))
                            Box(
                                Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .then(
                                        if (on) Modifier.background(Color.White)
                                        else Modifier.background(Color.Black.copy(alpha = 0.25f)).border(1.5.dp, Color.White.copy(alpha = 0.85f), CircleShape),
                                    ),
                                contentAlignment = Alignment.Center,
                            ) {
                                if (on) Icon(Icons.Rounded.Check, null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        if (chosen.isNotEmpty()) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp, start = 16.dp, end = 16.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                PrimaryPill("Восстановить", { onRestore(chosen) }, Modifier.weight(1f))
                PrimaryPill("Удалить навсегда", { onDeleteForever(chosen) }, Modifier.weight(1f))
            }
        }
    }
}
