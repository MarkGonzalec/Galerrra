package com.galera.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.galera.app.data.Photo

/**
 * Ввод PIN: при создании просит ввести код дважды, при входе проверяет.
 * [onDone] возвращает true, если код принят (вызывающий сам закрывает окно).
 */
@Composable
fun PinDialog(creating: Boolean, onDone: (String) -> Boolean, onDismiss: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var first by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    val title = when {
        !creating -> "Введите PIN"
        first == null -> "Придумайте PIN"
        else -> "Повторите PIN"
    }
    fun submit() {
        if (pin.length < 4) {
            error = "Минимум 4 цифры"
            return
        }
        if (creating) {
            val f = first
            if (f == null) {
                first = pin
                pin = ""
                error = null
            } else if (f == pin) {
                onDone(pin)
            } else {
                first = null
                pin = ""
                error = "Коды не совпали, начните заново"
            }
        } else if (!onDone(pin)) {
            pin = ""
            error = "Неверный PIN"
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                if (creating && first == null) {
                    Text(
                        "От 4 до 8 цифр. Скрытые фото пропадут из галереи и коллекций и открываются только по этому коду. " +
                            "Забытый PIN восстановить нельзя.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.size(10.dp))
                }
                OutlinedTextField(
                    value = pin,
                    onValueChange = { v -> pin = v.filter { it.isDigit() }.take(8); error = null },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    isError = error != null,
                    supportingText = error?.let { e -> { Text(e) } },
                )
            }
        },
        confirmButton = { TextButton(onClick = { submit() }) { Text(if (creating && first == null) "Далее" else "ОК") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

/** Скрытая папка: долгое нажатие выбирает, тап открывает; «Вернуть» делает фото видимыми. */
@Composable
fun HiddenScreen(
    photos: List<Photo>,
    columns: Int,
    onBack: () -> Unit,
    onOpen: (List<Photo>, Int) -> Unit,
    onUnhide: (List<Long>) -> Unit,
) {
    val selected = remember { mutableListOf<Long>().toMutableStateList() }
    LaunchedEffect(photos) {
        val ids = photos.mapTo(HashSet()) { it.id }
        selected.removeAll { it !in ids }
    }
    val selecting = selected.isNotEmpty()

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                GlassButton(onClick = { if (selecting) selected.clear() else onBack() }, size = 40.dp) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад", tint = LocalInk.current.ink, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (selecting) "Выбрано: ${selected.size}" else "Скрытая папка", style = MaterialTheme.typography.titleLarge)
                    Text(
                        if (selecting) "Нажимайте на фото, чтобы добавить или снять" else "${photos.size} в скрытых · долгое нажатие — выбрать",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (photos.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Здесь пока пусто.\nВыберите фото во «Всех фото» и нажмите «Скрыть».",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    contentPadding = PaddingValues(start = 3.dp, end = 3.dp, bottom = 130.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    items(photos.size, key = { photos[it].id }) { index ->
                        val photo = photos[index]
                        val on = photo.id in selected
                        val onTap by rememberUpdatedState<() -> Unit> {
                            if (selecting) {
                                if (on) selected.remove(photo.id) else selected.add(photo.id)
                            } else onOpen(photos, index)
                        }
                        val onLong by rememberUpdatedState<() -> Unit> { if (!on) selected.add(photo.id) }
                        Box(
                            Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .pointerInput(Unit) {
                                    detectTapGestures(onLongPress = { onLong() }, onTap = { onTap() })
                                },
                        ) {
                            PhotoImage(photo.uri, Modifier.fillMaxSize(), px = 360)
                            if (photo.isVideo) VideoBadge(photo.durationMs, Modifier.align(Alignment.BottomStart).padding(5.dp))
                            if (selecting) {
                                Box(
                                    Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(8.dp)
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .then(
                                            if (on) Modifier.background(Color.White)
                                            else Modifier.background(Color.Black.copy(alpha = 0.25f)).border(1.5.dp, Color.White.copy(alpha = 0.85f), CircleShape),
                                        ),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    if (on) Icon(Icons.Rounded.Check, null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
        if (selecting) {
            PrimaryPill(
                "Вернуть в галерею",
                { onUnhide(selected.toList()); selected.clear() },
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp, start = 24.dp, end = 24.dp)
                    .fillMaxWidth(),
            )
        }
    }
}
