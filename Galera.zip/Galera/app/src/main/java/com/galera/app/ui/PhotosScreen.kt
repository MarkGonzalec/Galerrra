package com.galera.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import com.galera.app.data.Album
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.alpha
import androidx.compose.runtime.toMutableStateList
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.Collections
import androidx.compose.material.icons.rounded.Check
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.border
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.fadeOut
import androidx.compose.animation.fadeIn
import androidx.compose.animation.core.animateFloatAsState
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Tag
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.galera.app.data.Photo
import com.galera.app.data.PhotoMeta
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private class MonthGroup(val key: Int, val label: String, val items: List<IndexedValue<Photo>>)

/**
 * Все фото устройства: группировка по месяцам, фильтр «Избранное», фильтр по тегу и поиск
 * по тегам и заметкам. [onOpen] получает ровно тот список, что виден на экране, и индекс в нём.
 */
@Composable
fun PhotosScreen(
    photos: List<Photo>,
    favorites: Set<Long>,
    meta: Map<Long, PhotoMeta>,
    popularTags: List<Pair<String, Int>>,
    albums: List<Album>,
    columns: Int,
    onColumns: (Int) -> Unit,
    onOpen: (list: List<Photo>, index: Int) -> Unit,
    onSelectingChange: (Boolean) -> Unit,
    onAddToAlbum: (ids: List<Long>, album: Album) -> Unit,
    onNewAlbum: (ids: List<Long>, name: String) -> Unit,
    onTagMany: (ids: List<Long>, tag: String) -> Unit,
    onFavoriteMany: (ids: List<Long>, favorite: Boolean) -> Unit,
    onHideMany: (List<Long>) -> Unit,
    onDeleteMany: ((List<Photo>) -> Unit)?,
) {
    var onlyFav by rememberSaveable { mutableStateOf(false) }
    var onlyVideo by rememberSaveable { mutableStateOf(false) }
    var tagFilter by rememberSaveable { mutableStateOf<String?>(null) }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    val focus = LocalFocusManager.current
    val haptic = LocalHapticFeedback.current

    // выбранные фото (режим выбора включается долгим нажатием)
    val selected = rememberSaveable(
        saver = listSaver<SnapshotStateList<Long>, Long>(
            save = { it.toList() },
            restore = { it.toMutableStateList() },
        ),
    ) { mutableListOf<Long>().toMutableStateList() }
    val selecting = selected.isNotEmpty()
    val selectedSet = remember(selected.size, selected.toList()) { selected.toHashSet() }
    var dialog by remember { mutableStateOf(0) } // 0 — нет, 1 — «в коллекцию», 2 — «тег»

    fun toggle(id: Long) {
        if (!selected.remove(id)) selected.add(id)
    }

    LaunchedEffect(selecting) { onSelectingChange(selecting) }
    DisposableEffect(Unit) { onDispose { onSelectingChange(false) } }
    BackHandler(enabled = selecting) { selected.clear() }
    // фото могли удалить — убираем их из выбора
    LaunchedEffect(photos) {
        if (selected.isNotEmpty()) {
            val ids = photos.mapTo(HashSet()) { it.id }
            selected.removeAll { it !in ids }
        }
    }

    // если выбранный тег исчез (убрали со всех фото) — сбрасываем фильтр
    val activeTag = tagFilter?.takeIf { t -> popularTags.any { it.first.equals(t, ignoreCase = true) } }

    val shown = remember(photos, favorites, onlyFav, onlyVideo, meta, activeTag, query, searchOpen) {
        val q = if (searchOpen) query.trim().lowercase() else ""
        photos.filter { p ->
            val m = meta[p.id]
            (!onlyFav || p.id in favorites) &&
                (!onlyVideo || p.isVideo) &&
                (activeTag == null || m?.tags?.any { it.equals(activeTag, ignoreCase = true) } == true) &&
                (q.isEmpty() || (m != null && (m.note.lowercase().contains(q) || m.tags.any { it.lowercase().contains(q) })))
        }
    }
    val favCount = remember(photos, favorites) {
        val ids = photos.mapTo(HashSet()) { it.id }
        favorites.count { it in ids }
    }
    val groups = remember(shown) {
        val fmt = SimpleDateFormat("LLLL yyyy", Locale("ru"))
        val cal = Calendar.getInstance()
        shown.withIndex()
            .groupBy {
                cal.timeInMillis = it.value.dateMillis
                cal.get(Calendar.YEAR) * 12 + cal.get(Calendar.MONTH)
            }
            .map { (key, list) ->
                val label = fmt.format(Date(list.first().value.dateMillis)).replaceFirstChar { it.uppercase() }
                MonthGroup(key, label, list)
            }
    }

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Column(Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 16.dp, bottom = 8.dp)) {
            if (selecting) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlassButton(onClick = { selected.clear() }, size = 40.dp) {
                        Icon(Icons.Rounded.Close, "Отменить выбор", tint = LocalInk.current.ink, modifier = Modifier.size(20.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Выбрано: ${selected.size}", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "Нажимайте на фото, чтобы добавить или снять",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    val allSelected = shown.isNotEmpty() && shown.all { it.id in selectedSet }
                    SegmentPill(
                        text = if (allSelected) "Снять" else "Все",
                        selected = false,
                        onClick = {
                            if (allSelected) selected.clear()
                            else shown.forEach { if (it.id !in selectedSet) selected.add(it.id) }
                        },
                    )
                }
            } else {
                Text("Все фото", style = MaterialTheme.typography.headlineLarge)
                Text(
                    "${photos.size} фото · $favCount в избранном",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(
                    Modifier.padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    FilterPill("Все", !onlyFav && !onlyVideo) { onlyFav = false; onlyVideo = false }
                    FilterPill("Избранное", onlyFav) { onlyFav = true; onlyVideo = false }
                    FilterPill("Видео", onlyVideo) { onlyVideo = true; onlyFav = false }
                    Spacer(Modifier.weight(1f))
                    GlassButton(
                        onClick = {
                            searchOpen = !searchOpen
                            if (!searchOpen) {
                                query = ""
                                focus.clearFocus()
                            }
                        },
                        size = 40.dp,
                    ) {
                        Icon(
                            if (searchOpen) Icons.Rounded.Close else Icons.Rounded.Search,
                            if (searchOpen) "Закрыть поиск" else "Поиск",
                            tint = LocalInk.current.ink,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
                AnimatedVisibility(visible = searchOpen) {
                    SearchField(query, { query = it }, Modifier.padding(top = 12.dp))
                }
            }
        }

        if (popularTags.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 6.dp),
            ) {
                items(popularTags, key = { it.first.lowercase() }) { (tag, count) ->
                    val isOn = activeTag != null && activeTag.equals(tag, ignoreCase = true)
                    TagChip(
                        text = "$tag · $count",
                        selected = isOn,
                        onClick = { tagFilter = if (isOn) null else tag },
                        colorKey = tag,
                    )
                }
            }
        }

        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    when {
                        onlyVideo && activeTag == null && !searchOpen -> "Видео не найдены"
                        onlyFav && activeTag == null && !searchOpen -> "Пока нет избранных.\nОткройте фото и нажмите сердечко."
                        photos.isEmpty() -> "Фото не найдены"
                        else -> "Ничего не найдено"
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(columns),
                modifier = Modifier.pinchColumns(columns, onColumns),
                contentPadding = PaddingValues(start = 3.dp, end = 3.dp, bottom = 170.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                groups.forEach { group ->
                    item(key = "month${group.key}", span = { GridItemSpan(maxLineSpan) }) {
                        val allInGroup = group.items.all { it.value.id in selectedSet }
                        Row(
                            Modifier.fillMaxWidth().padding(start = 12.dp, end = 8.dp, top = 12.dp, bottom = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                group.label,
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.weight(1f),
                            )
                            if (selecting) {
                                SegmentPill(
                                    text = if (allInGroup) "Снять месяц" else "Выбрать месяц",
                                    selected = false,
                                    onClick = {
                                        if (allInGroup) {
                                            val ids = group.items.mapTo(HashSet()) { it.value.id }
                                            selected.removeAll { it in ids }
                                        } else {
                                            group.items.forEach { if (it.value.id !in selectedSet) selected.add(it.value.id) }
                                        }
                                    },
                                )
                            }
                        }
                    }
                    items(group.items, key = { it.value.id }) { indexed ->
                        val photo = indexed.value
                        PhotoTile(
                            photo = photo,
                            checked = photo.id in selectedSet,
                            selecting = selecting,
                            hasMeta = meta[photo.id] != null,
                            isFavorite = photo.id in favorites,
                            onTap = {
                                if (selecting) toggle(photo.id) else onOpen(shown, indexed.index)
                            },
                            onLongPress = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                toggle(photo.id)
                            },
                        )
                    }
                }
            }
        }
    }

    AnimatedVisibility(
        visible = selecting,
        modifier = Modifier.align(Alignment.BottomCenter),
        enter = fadeIn() + slideInVertically { it },
        exit = fadeOut() + slideOutVertically { it },
    ) {
        val allFav = selected.isNotEmpty() && selected.all { it in favorites }
        Row(
            Modifier
                .navigationBarsPadding()
                .padding(bottom = 16.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(GaleraPill.copy(alpha = 0.97f))
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(28.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
        ) {
            ActionItem(Icons.Rounded.Collections, "Коллекция", Color.White) { dialog = 1 }
            ActionItem(Icons.Rounded.Tag, "Тег", Color.White) { dialog = 2 }
            ActionItem(
                Icons.Rounded.Favorite,
                if (allFav) "Убрать" else "Избранное",
                if (allFav) Color(0xFFFF8A80) else Color.White,
            ) {
                onFavoriteMany(selected.toList(), !allFav)
                selected.clear()
            }
            ActionItem(Icons.Rounded.VisibilityOff, "Скрыть", Color.White) {
                onHideMany(selected.toList())
                selected.clear()
            }
            if (onDeleteMany != null) {
                ActionItem(Icons.Rounded.Delete, "В корзину", Color(0xFFFF8A80)) {
                    onDeleteMany(photos.filter { it.id in selectedSet })
                }
            }
        }
    }
    }

    when (dialog) {
        1 -> AddToAlbumDialog(
            albums = albums,
            count = selected.size,
            onPick = { album ->
                onAddToAlbum(selected.toList(), album)
                selected.clear()
                dialog = 0
            },
            onNew = { name ->
                onNewAlbum(selected.toList(), name)
                selected.clear()
                dialog = 0
            },
            onDismiss = { dialog = 0 },
        )
        2 -> TagManyDialog(
            count = selected.size,
            popularTags = popularTags.map { it.first },
            onApply = { tag ->
                onTagMany(selected.toList(), tag)
                selected.clear()
                dialog = 0
            },
            onDismiss = { dialog = 0 },
        )
    }
}

/** Плитка фото: тап открывает/переключает выбор, долгое нажатие включает режим выбора. */
@Composable
private fun PhotoTile(
    photo: Photo,
    checked: Boolean,
    selecting: Boolean,
    hasMeta: Boolean,
    isFavorite: Boolean,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
) {
    val scale by animateFloatAsState(if (checked) 0.88f else 1f, label = "tileScale")
    val tap by rememberUpdatedState(onTap)
    val longPress by rememberUpdatedState(onLongPress)
    Box(
        Modifier
            .aspectRatio(1f)
            .captureHero()
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { longPress() }, onTap = { tap() })
            },
    ) {
        PhotoImage(
            photo.uri,
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .clip(RoundedCornerShape(if (checked) 14.dp else 6.dp)),
            px = 360,
        )
        if (selecting) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(24.dp)
                    .clip(CircleShape)
                    .then(
                        if (checked) Modifier.background(Color.White)
                        else Modifier.background(Color.Black.copy(alpha = 0.25f)).border(1.5.dp, Color.White.copy(alpha = 0.85f), CircleShape),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                if (checked) Icon(Icons.Rounded.Check, null, tint = Color.Black, modifier = Modifier.size(16.dp))
            }
        }
        if (photo.isVideo) {
            VideoBadge(photo.durationMs, Modifier.align(Alignment.TopStart).padding(6.dp))
        }
        if (hasMeta) {
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(5.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(4.dp),
            ) {
                Icon(Icons.Rounded.Tag, "Есть теги или заметка", tint = Color.White, modifier = Modifier.size(12.dp))
            }
        }
        if (isFavorite) {
            Icon(
                Icons.Rounded.Favorite,
                contentDescription = null,
                tint = Color(0xFFFF8A80),
                modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp).size(16.dp),
            )
        }
    }
}

@Composable
private fun ActionItem(icon: ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    Column(
        Modifier
            .width(66.dp)
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.size(4.dp))
        Text(label, color = tint, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val focus = LocalFocusManager.current
    Row(
        modifier
            .fillMaxWidth()
            .clip(CircleShape)
            .background(LocalInk.current.ink.copy(alpha = 0.08f))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Search, null, tint = LocalInk.current.ink.copy(alpha = 0.5f), modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = LocalInk.current.ink, fontSize = 16.sp),
            cursorBrush = SolidColor(LocalInk.current.ink),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) {
                        Text("Поиск по тегам и заметкам", color = LocalInk.current.ink.copy(alpha = 0.4f), fontSize = 16.sp)
                    }
                    inner()
                }
            },
        )
    }
}

@Composable
private fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(if (selected) LocalInk.current.ink else LocalInk.current.ink.copy(alpha = 0.10f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(
            text,
            color = if (selected) LocalInk.current.onInk else LocalInk.current.ink,
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}
