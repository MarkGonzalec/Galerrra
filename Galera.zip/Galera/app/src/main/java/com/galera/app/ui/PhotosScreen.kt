package com.galera.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.galera.app.data.Photo
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private class MonthGroup(val key: Int, val label: String, val items: List<IndexedValue<Photo>>)

/**
 * Все фото устройства, сгруппированные по месяцам, с фильтром «Избранное».
 * [onOpen] получает источник ("all" или "fav") и индекс в показанном списке.
 */
@Composable
fun PhotosScreen(
    photos: List<Photo>,
    favorites: Set<Long>,
    onOpen: (source: String, index: Int) -> Unit,
) {
    var onlyFav by rememberSaveable { mutableStateOf(false) }
    val shown = remember(photos, favorites, onlyFav) {
        if (onlyFav) photos.filter { it.id in favorites } else photos
    }
    val favCount = remember(photos, favorites) {
        val ids = photos.mapTo(HashSet()) { it.id }
        favorites.count { it in ids }
    }
    val groups = remember(shown) {
        val fmt = SimpleDateFormat("LLLL yyyy", Locale("ru"))
        val cal = Calendar.getInstance()
        shown.withIndex()
            .groupBy {
                cal.timeInMillis = it.value.dateMillis
                cal.get(Calendar.YEAR) * 12 + cal.get(Calendar.MONTH)
            }
            .map { (key, list) ->
                val label = fmt.format(Date(list.first().value.dateMillis)).replaceFirstChar { it.uppercase() }
                MonthGroup(key, label, list)
            }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp)) {
            Text("Все фото", style = MaterialTheme.typography.headlineLarge)
            Text(
                "${photos.size} фото · $favCount в избранном",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterPill("Все", !onlyFav) { onlyFav = false }
                FilterPill("Избранное", onlyFav) { onlyFav = true }
            }
        }

        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (onlyFav) "Пока нет избранных.\nОткройте фото и нажмите сердечко." else "Фото не найдены",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(start = 3.dp, end = 3.dp, bottom = 150.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                groups.forEach { group ->
                    item(key = "month${group.key}", span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            group.label,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(start = 12.dp, top = 16.dp, bottom = 6.dp),
                        )
                    }
                    items(group.items, key = { it.value.id }) { indexed ->
                        Box(
                            Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                                    onOpen(if (onlyFav) "fav" else "all", indexed.index)
                                },
                        ) {
                            PhotoImage(indexed.value.uri, Modifier.fillMaxSize(), px = 360)
                            if (indexed.value.id in favorites) {
                                Icon(
                                    Icons.Rounded.Favorite,
                                    contentDescription = null,
                                    tint = Color(0xFFFF8A80),
                                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp).size(16.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.10f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(
            text,
            color = if (selected) Color.Black else Color.White,
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}
