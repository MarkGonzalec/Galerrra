package com.galera.app.ui

import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.galera.app.data.Photo
import kotlinx.coroutines.delay

/**
 * Страница видео в просмотре. Использует встроенный VideoView — без тяжёлых библиотек,
 * хорошо для старых телефонов. Плеер создаётся только после нажатия «play»
 * и освобождается при перелистывании.
 */
@Composable
fun VideoPage(
    photo: Photo,
    isCurrent: Boolean,
    chrome: Boolean,
    onTap: () -> Unit,
) {
    var videoView by remember { mutableStateOf<VideoView?>(null) }
    var started by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableIntStateOf(0) }
    var dur by remember { mutableIntStateOf(photo.durationMs.toInt().coerceAtLeast(1)) }
    var dragging by remember { mutableStateOf(false) }
    val view = LocalView.current

    LaunchedEffect(isCurrent) {
        if (!isCurrent) {
            started = false
            playing = false
            pos = 0
        }
    }
    LaunchedEffect(playing, dragging) {
        while (playing && !dragging) {
            videoView?.let { pos = it.currentPosition }
            delay(250)
        }
    }
    DisposableEffect(playing) {
        view.keepScreenOn = playing
        onDispose { view.keepScreenOn = false }
    }

    fun toggle() {
        val v = videoView
        when {
            !started -> started = true
            playing -> {
                v?.pause()
                playing = false
            }
            else -> {
                v?.start()
                playing = true
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onTap() },
    ) {
        if (!started) {
            PhotoImage(photo.uri, Modifier.fillMaxSize(), px = 1080, contentScale = ContentScale.Fit)
        } else {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    val vv = VideoView(ctx)
                    vv.setVideoURI(photo.uri)
                    vv.setOnPreparedListener { mp ->
                        dur = mp.duration.coerceAtLeast(1)
                        vv.start()
                        playing = true
                    }
                    vv.setOnCompletionListener {
                        playing = false
                        started = false
                        pos = 0
                    }
                    vv.setOnErrorListener { _, _, _ ->
                        playing = false
                        started = false
                        true
                    }
                    videoView = vv
                    FrameLayout(ctx).apply {
                        addView(
                            vv,
                            FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                Gravity.CENTER,
                            ),
                        )
                        // тапы обрабатывает Compose
                        vv.isClickable = false
                        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    }
                },
                onRelease = {
                    videoView?.stopPlayback()
                    videoView = null
                },
            )
        }

        if (!playing) {
            Box(
                Modifier
                    .align(Alignment.Center)
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.55f))
                    .clickable { toggle() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.PlayArrow, "Воспроизвести", tint = Color.White, modifier = Modifier.size(44.dp))
            }
        }

        if (chrome && started) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 150.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).clickable { toggle() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (playing) "Пауза" else "Воспроизвести",
                        tint = Color.White,
                    )
                }
                Text(formatDuration(pos.toLong()), color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 6.dp))
                Slider(
                    value = pos.toFloat().coerceIn(0f, dur.toFloat()),
                    onValueChange = {
                        dragging = true
                        pos = it.toInt()
                    },
                    onValueChangeFinished = {
                        videoView?.seekTo(pos)
                        dragging = false
                    },
                    valueRange = 0f..dur.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color.White,
                        inactiveTrackColor = Color.White.copy(alpha = 0.3f),
                    ),
                    modifier = Modifier.weight(1f),
                )
                Text(formatDuration(dur.toLong()), color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp).width(44.dp))
            }
        }
    }
}
