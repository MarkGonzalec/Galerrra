package com.galera.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.galera.app.data.Photo

/**
 * Точные дубликаты: одинаковое содержимое. В каждой группе самое раннее фото остаётся,
 * остальные отмечены к удалению — тап по фото меняет отметку.
 */
@Composable
fun DuplicatesScreen(
    running: Boolean,
    progress: Pair<Int, Int>,
    groups: List<List<Photo>>?,
    alive: Set<Long>,
    onScan: () -> Unit,
    onBack: () -> Unit,
    onTrash: ((List<Photo>) -> Unit)?,
) {
    LaunchedEffect(Unit) { if (groups == null) onScan() }

    val live = remember(groups, alive) {
        groups.orEmpty().map { g -> g.filter { it.id in alive } }.filter { it.size >= 2 }
    }
    // к удалению: все, кроме первого в каждой группе
    val marked = remember(live) { live.flatMap { g -> g.drop(1).map { it.id } }.toMutableStateList() }
    val toDelete = live.flatten().filter { it.id in marked }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                GlassButton(onClick = onBack, size = 40.dp) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад", tint = LocalInk.current.ink, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Дубликаты", style = MaterialTheme.typography.titleLarge)
                    Text(
                        when {
                            running -> "Сравниваю файлы…"
                            live.isEmpty() -> "Ничего лишнего не найдено"
                            else -> "Групп: ${live.size} · можно освободить ${toDelete.size} файл(ов)"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            when {
                running -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(12.dp))
                        Text(
                            if (progress.second > 0) "${progress.first} из ${progress.second}" else "Готовлюсь…",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                live.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Одинаковых файлов нет.\nИщутся только точные копии.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                else -> LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                ) {
                    items(live.size) { gi ->
                        val group = live[gi]
                        Column {
                            Text(
                                "Группа ${gi + 1} · ${group.size} копии",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(bottom = 8.dp),
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(group, key = { it.id }) { photo ->
                                    val on = photo.id in marked
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(
                                            Modifier
                                                .size(104.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .clickable { if (on) marked.remove(photo.id) else marked.add(photo.id) },
                                        ) {
                                            PhotoImage(photo.uri, Modifier.fillMaxSize(), px = 300)
                                            if (on) {
                                                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)))
                                                Box(
                                                    Modifier
                                                        .align(Alignment.TopEnd)
                                                        .padding(6.dp)
                                                        .size(22.dp)
                                                        .clip(CircleShape)
                                                        .background(Color(0xFFFF8A80)),
                                                    contentAlignment = Alignment.Center,
                                                ) { Icon(Icons.Rounded.Check, null, tint = Color.Black, modifier = Modifier.size(15.dp)) }
                                            }
                                        }
                                        Text(
                                            if (on) "Удалить" else "Оставить",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (on) Color(0xFFFF8A80) else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(top = 4.dp),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (!running && toDelete.isNotEmpty()) {
            Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp).fillMaxWidth()) {
                if (onTrash != null) {
                    PrimaryPill("В корзину: ${toDelete.size}", { onTrash(toDelete) }, Modifier.fillMaxWidth())
                } else {
                    Text(
                        "Удаление из приложения доступно на Android 11 и новее.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
