package com.galera.app.ui

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEvent
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput

/**
 * Щипок двумя пальцами меняет число колонок (2–5): растянуть — крупнее, свести — мельче.
 * События не перехватываются, прокрутка работает как обычно.
 */
fun Modifier.pinchColumns(columns: Int, onColumns: (Int) -> Unit): Modifier =
    pointerInput(columns) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            var zoom = 1f
            var done = false
            var event: PointerEvent
            do {
                event = awaitPointerEvent(PointerEventPass.Initial)
                if (!done && event.changes.size >= 2) {
                    zoom *= event.calculateZoom()
                    if (zoom > 1.3f) {
                        onColumns((columns - 1).coerceAtLeast(2))
                        done = true
                    } else if (zoom < 0.77f) {
                        onColumns((columns + 1).coerceAtMost(5))
                        done = true
                    }
                }
            } while (event.changes.any { it.pressed })
        }
    }
