package com.galera.app.ui

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext

/** Откуда «вырастает» просмотр: центр последней нажатой плитки (доли экрана). */
object Hero {
    var origin: TransformOrigin = TransformOrigin.Center
}

/** Запоминает положение плитки при касании (не перехватывая само нажатие). */
@Composable
fun Modifier.captureHero(): Modifier {
    val dm = LocalContext.current.resources.displayMetrics
    val center = remember { FloatArray(2) }
    return this
        .onGloballyPositioned {
            val r = it.boundsInRoot()
            center[0] = r.center.x
            center[1] = r.center.y
        }
        .pointerInput(Unit) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                Hero.origin = TransformOrigin(
                    (center[0] / dm.widthPixels).coerceIn(0f, 1f),
                    (center[1] / dm.heightPixels).coerceIn(0f, 1f),
                )
            }
        }
}
