package com.galera.app.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.galera.app.data.Photo
import com.galera.app.data.PhotoMeta

/** Умная подборка: собирается сама по правилам, хранить ничего не нужно. */
class Smart(val key: String, val title: String, val photos: List<Photo>)

private const val MONTH_MS = 30L * 24 * 60 * 60 * 1000

fun buildSmart(photos: List<Photo>, favorites: Set<Long>, meta: Map<Long, PhotoMeta>): List<Smart> {
    val now = System.currentTimeMillis()
    fun bucketHas(p: Photo, vararg parts: String) = parts.any { p.bucket.contains(it, ignoreCase = true) }
    return listOf(
        Smart("recent", "Недавние", photos.filter { now - it.dateMillis <= MONTH_MS }),
        Smart("fav", "Избранное", photos.filter { it.id in favorites }),
        Smart("videos", "Видео", photos.filter { it.isVideo }),
        Smart("screens", "Скриншоты", photos.filter { bucketHas(it, "screenshot", "скриншот", "screen") }),
        Smart("camera", "Камера", photos.filter { !it.isVideo && bucketHas(it, "camera", "камера", "100andro") }),
        Smart("tagged", "С тегами", photos.filter { meta[it.id]?.let { m -> m.tags.isNotEmpty() } == true }),
    ).filter { it.photos.isNotEmpty() }
}

/** Ряд умных подборок в начале главной. */
@Composable
fun SmartRow(items: List<Smart>, onOpen: (String) -> Unit, modifier: Modifier = Modifier) {
    if (items.isEmpty()) return
    Column(modifier) {
        Text(
            "Умные коллекции",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 10.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(0.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(items, key = { it.key }) { smart ->
                val cover: Uri? = smart.photos.firstOrNull()?.uri
                Box(
                    Modifier
                        .width(112.dp)
                        .aspectRatio(0.9f)
                        .clip(RoundedCornerShape(18.dp))
                        .clickable { onOpen(smart.key) },
                ) {
                    if (cover != null) PhotoImage(cover, Modifier.fillMaxSize(), px = 300)
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f)), startY = 120f)),
                    )
                    Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
                        Text(smart.title, color = Color.White, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${smart.photos.size}", color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
    }
}
