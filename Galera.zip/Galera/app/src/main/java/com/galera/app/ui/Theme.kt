package com.galera.app.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Акценты коллекций — приглушённые пастельные цвета, хорошо смотрятся на тёмном фоне. */
val Accents = listOf(
    Color(0xFFFF8A80),
    Color(0xFF8C9EFF),
    Color(0xFF80CBC4),
    Color(0xFFFFD180),
    Color(0xFFCE93D8),
    Color(0xFF81D4FA),
)

val GaleraBg = Color(0xFF09090B)
val GaleraPill = Color(0xFF1B1B20)

/** Засечный шрифт для крупных заголовков (как «Japan» и «Pool» в референсах). */
val Display = FontFamily.Serif

private val DarkColors = darkColorScheme(
    primary = Color(0xFFF2F2F5),
    onPrimary = Color(0xFF09090B),
    background = GaleraBg,
    onBackground = Color(0xFFF2F2F5),
    surface = Color(0xFF17171B),
    onSurface = Color(0xFFF2F2F5),
    surfaceVariant = Color(0xFF232329),
    onSurfaceVariant = Color(0xFF9A9AA5),
    outline = Color(0xFF3A3A42),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF16161A),
    onPrimary = Color(0xFFFFFFFF),
    background = Color(0xFFF6F6F9),
    onBackground = Color(0xFF16161A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF16161A),
    surfaceVariant = Color(0xFFEBEBF0),
    onSurfaceVariant = Color(0xFF666672),
    outline = Color(0xFFC8C8D0),
)

/** Цвета «чернил» для кнопок и значков: на тёмной теме белые, на светлой — тёмные. */
class GaleraInk(val ink: Color, val onInk: Color, val pill: Color, val light: Boolean)

val DarkInk = GaleraInk(ink = Color.White, onInk = Color.Black, pill = GaleraPill, light = false)
val LightInk = GaleraInk(ink = Color(0xFF16161A), onInk = Color.White, pill = Color(0xFFE4E4EA), light = true)
val LocalInk = staticCompositionLocalOf { DarkInk }

private val GaleraTypography = Typography(
    headlineLarge = TextStyle(fontFamily = Display, fontWeight = FontWeight.SemiBold, fontSize = 34.sp),
    headlineMedium = TextStyle(fontFamily = Display, fontWeight = FontWeight.SemiBold, fontSize = 28.sp),
    titleLarge = TextStyle(fontFamily = Display, fontWeight = FontWeight.SemiBold, fontSize = 22.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 17.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    bodySmall = TextStyle(fontSize = 12.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
)

/** true — слабое устройство или включён «Экономичный режим»: меньше теней, анимаций и размер картинок. */
val LocalLowEnd = staticCompositionLocalOf { false }

@Composable
fun GaleraTheme(lowEnd: Boolean = false, light: Boolean = false, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (light) LightColors else DarkColors, typography = GaleraTypography) {
        CompositionLocalProvider(
            LocalLowEnd provides lowEnd,
            LocalInk provides (if (light) LightInk else DarkInk),
        ) {
            // Surface задаёт цвет текста по умолчанию (светлый). Без него Text без явного цвета
            // становится чёрным на тёмном фоне — это и была ошибка с невидимым заголовком.
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background,
                contentColor = MaterialTheme.colorScheme.onBackground,
            ) { content() }
        }
    }
}

/** Экраны, которые всегда тёмные (просмотр, редактор, коллекция), даже при светлой теме приложения. */
@Composable
fun DarkScope(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, typography = GaleraTypography) {
        CompositionLocalProvider(LocalInk provides DarkInk) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = GaleraBg,
                contentColor = MaterialTheme.colorScheme.onBackground,
            ) { content() }
        }
    }
}
