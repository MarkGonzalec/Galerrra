package com.galera.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Tag
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.galera.app.data.Photo
import com.galera.app.data.PhotoMeta
import kotlinx.coroutines.delay

private val SheetBg = Color(0xFF16161A)
private val FieldBg = Color.White.copy(alpha = 0.08f)

/** Цвет тега берётся из палитры по хэшу названия — один и тот же тег всегда одного цвета. */
fun tagColor(tag: String): Color =
    Accents[(tag.lowercase().hashCode() and 0x7fffffff) % Accents.size]

/** Цветная «таблетка» с названием тега. [onRemove] добавляет крестик, [onClick] делает чип нажимаемым. */
@Composable
fun TagChip(
    text: String,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null,
    onRemove: (() -> Unit)? = null,
    colorKey: String = text,
) {
    val color = tagColor(colorKey)
    Row(
        modifier
            .clip(CircleShape)
            .background(if (selected) color else color.copy(alpha = 0.16f))
            .border(1.dp, color.copy(alpha = if (selected) 1f else 0.35f), CircleShape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(start = 12.dp, end = if (onRemove != null) 6.dp else 12.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "#$text",
            color = if (selected) Color.Black else color,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
        )
        if (onRemove != null) {
            Spacer(Modifier.width(6.dp))
            Box(
                Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.25f))
                    .clickable(onClick = onRemove),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Close, "Убрать тег", tint = color, modifier = Modifier.size(12.dp))
            }
        }
    }
}

/** Плашка внизу просмотра: показывает теги и заметку, по нажатию открывает шторку. */
@Composable
fun MetaPill(meta: PhotoMeta, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.12f))
            .border(1.dp, Color.White.copy(alpha = 0.10f), CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Tag, null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        if (meta.isEmpty) {
            Text("Теги и заметка", color = Color.White, style = MaterialTheme.typography.bodyMedium)
        } else {
            meta.tags.take(3).forEach { tag ->
                Text("#$tag", color = tagColor(tag), style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                Spacer(Modifier.width(8.dp))
            }
            if (meta.tags.size > 3) {
                Text(
                    "+${meta.tags.size - 3}",
                    color = Color.White.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.bodyMedium,
                )
                Spacer(Modifier.width(8.dp))
            }
            if (meta.note.isNotBlank()) {
                Icon(Icons.Rounded.Edit, "Есть заметка", tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(15.dp))
            }
        }
    }
}

/**
 * Нижняя шторка «Теги и заметка»: чипы тегов, поле нового тега, подсказки из часто используемых
 * и заметка. Заметка сохраняется сама — через полсекунды после ввода и при закрытии шторки.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DetailsSheet(
    photo: Photo,
    meta: PhotoMeta,
    popularTags: List<String>,
    onAddTag: (String) -> Unit,
    onRemoveTag: (String) -> Unit,
    onNote: (String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var tagInput by remember(photo.id) { mutableStateOf("") }
    var note by remember(photo.id) { mutableStateOf(meta.note) }
    val focus = LocalFocusManager.current
    val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)

    // автосохранение заметки
    LaunchedEffect(photo.id, note) {
        delay(500)
        if (note.trim() != meta.note) onNote(note)
    }
    // и сохранение при закрытии шторки (в том числе по тапу на затемнение)
    val latestNote by rememberUpdatedState(note)
    val latestSaved by rememberUpdatedState(meta.note)
    DisposableEffect(photo.id) {
        onDispose { if (latestNote.trim() != latestSaved) onNote(latestNote) }
    }

    fun submitTag() {
        if (tagInput.isNotBlank()) {
            onAddTag(tagInput)
            tagInput = ""
        }
    }

    Column(
        modifier
            .fillMaxWidth()
            .heightIn(max = 640.dp)
            .clip(shape)
            .background(SheetBg)
            .border(1.dp, Color.White.copy(alpha = 0.08f), shape)
            // поглощаем нажатия, чтобы тап по шторке не закрывал её через затемнение
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 20.dp),
    ) {
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .size(width = 40.dp, height = 4.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.25f)),
        )
        Spacer(Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Теги и заметка", style = MaterialTheme.typography.titleLarge)
                Text(
                    formatDate(photo.dateMillis),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Box(
                Modifier
                    .clip(CircleShape)
                    .background(Color.White)
                    .clickable {
                        focus.clearFocus()
                        onClose()
                    }
                    .padding(horizontal = 18.dp, vertical = 9.dp),
            ) {
                Text("Готово", color = Color.Black, style = MaterialTheme.typography.labelLarge)
            }
        }

        Spacer(Modifier.height(20.dp))
        SectionLabel("ТЕГИ")
        if (meta.tags.isEmpty()) {
            Text(
                "Тегов пока нет — добавьте первый ниже",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                meta.tags.forEach { tag -> TagChip(tag, onRemove = { onRemoveTag(tag) }) }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(CircleShape)
                .background(FieldBg)
                .padding(start = 16.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("#", color = Color.White.copy(alpha = 0.5f), fontSize = 16.sp)
            Spacer(Modifier.width(4.dp))
            BasicTextField(
                value = tagInput,
                onValueChange = {
                    // запятая или перенос строки завершают ввод тега
                    if (it.endsWith(",") || it.endsWith("\n")) {
                        onAddTag(it.dropLast(1))
                        tagInput = ""
                    } else {
                        tagInput = it.take(24)
                    }
                },
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submitTag() }),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (tagInput.isEmpty()) {
                            Text("Новый тег", color = Color.White.copy(alpha = 0.4f), fontSize = 16.sp)
                        }
                        inner()
                    }
                },
            )
            val canAdd = tagInput.isNotBlank()
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (canAdd) Color.White else Color.White.copy(alpha = 0.12f))
                    .clickable(enabled = canAdd) { submitTag() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Rounded.Add,
                    "Добавить тег",
                    tint = if (canAdd) Color.Black else Color.White.copy(alpha = 0.5f),
                    modifier = Modifier.size(20.dp),
                )
            }
        }

        val suggestions = popularTags.filter { t -> meta.tags.none { it.equals(t, ignoreCase = true) } }.take(10)
        if (suggestions.isNotEmpty()) {
            Spacer(Modifier.height(18.dp))
            SectionLabel("ЧАСТО ИСПОЛЬЗУЕТЕ")
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                suggestions.forEach { tag -> TagChip(tag, onClick = { onAddTag(tag) }) }
            }
        }

        Spacer(Modifier.height(22.dp))
        SectionLabel("ЗАМЕТКА")
        Box(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 110.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(FieldBg)
                .padding(16.dp),
        ) {
            BasicTextField(
                value = note,
                onValueChange = { note = it.take(1000) },
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp, lineHeight = 22.sp),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    Box {
                        if (note.isEmpty()) {
                            Text(
                                "Что запомнилось об этом фото?",
                                color = Color.White.copy(alpha = 0.4f),
                                fontSize = 16.sp,
                                lineHeight = 22.sp,
                            )
                        }
                        inner()
                    }
                },
            )
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        fontSize = 11.sp,
        letterSpacing = 1.2.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(bottom = 8.dp),
    )
}
