package com.galera.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.galera.app.data.Photo

/** Простая сетка фото с заголовком — для умных коллекций. Щипок меняет размер. */
@Composable
fun SimpleGridScreen(
    title: String,
    photos: List<Photo>,
    columns: Int,
    onColumns: (Int) -> Unit,
    onBack: () -> Unit,
    onOpen: (List<Photo>, Int) -> Unit,
) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            GlassButton(onClick = onBack, size = 40.dp) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад", tint = LocalInk.current.ink, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Text(
                    "${photos.size} шт.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            modifier = Modifier.fillMaxSize().pinchColumns(columns, onColumns),
            contentPadding = PaddingValues(start = 3.dp, end = 3.dp, bottom = 40.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            items(photos.size, key = { photos[it].id }) { index ->
                val photo = photos[index]
                Box(
                    Modifier
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .captureHero()
                        .clickable { onOpen(photos, index) },
                ) {
                    PhotoImage(photo.uri, Modifier.fillMaxSize(), px = 360)
                    if (photo.isVideo) VideoBadge(photo.durationMs, Modifier.align(Alignment.BottomStart).padding(5.dp))
                }
            }
        }
    }
}
