package com.galera.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Collections
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import androidx.compose.runtime.rememberCoroutineScope
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.galera.app.data.Device
import com.galera.app.data.Photo
import com.galera.app.ui.AlbumScreen
import com.galera.app.ui.AlbumsScreen
import com.galera.app.ui.Accents
import com.galera.app.ui.CardFan
import com.galera.app.ui.EditorScreen
import com.galera.app.ui.GaleraTheme
import com.galera.app.ui.DarkScope
import com.galera.app.ui.DuplicatesScreen
import com.galera.app.ui.HiddenScreen
import com.galera.app.ui.LocalInk
import com.galera.app.ui.PinDialog
import com.galera.app.ui.Hero
import com.galera.app.ui.PhotosScreen
import com.galera.app.ui.PickPhotosScreen
import com.galera.app.ui.PillSwitch
import com.galera.app.ui.PrimaryPill
import com.galera.app.ui.SettingsDialog
import com.galera.app.ui.SimpleGridScreen
import com.galera.app.ui.buildSmart
import com.galera.app.ui.TrashScreen
import com.galera.app.ui.ViewerScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
        )
        setContent {
            val vm: GalleryViewModel = viewModel()
            val economy by vm.economy.collectAsState()
            val themeMode by vm.theme.collectAsState()
            val systemDark = isSystemInDarkTheme()
            val light = when (themeMode) {
                1 -> true
                2 -> !systemDark
                else -> false
            }
            val lowEnd = remember(economy) {
                when (economy) {
                    1 -> true
                    2 -> false
                    else -> Device.isLowEnd(this@MainActivity)
                }
            }
            GaleraTheme(lowEnd = lowEnd, light = light) {
                Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                    GalleryApp(vm, light)
                }
            }
        }
    }
}

// ───────────────────────── разрешения ─────────────────────────

private fun mediaPermissions(): Array<String> = when {
    Build.VERSION.SDK_INT >= 34 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
    )
    Build.VERSION.SDK_INT >= 33 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VIDEO,
    )
    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

/** На Android 14+ достаточно и «выбранных фото» (частичный доступ). */
private fun hasMediaAccess(context: Context): Boolean {
    fun granted(p: String) = ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED
    return when {
        Build.VERSION.SDK_INT >= 34 ->
            granted(Manifest.permission.READ_MEDIA_IMAGES) || granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        Build.VERSION.SDK_INT >= 33 ->
            granted(Manifest.permission.READ_MEDIA_IMAGES) || granted(Manifest.permission.READ_MEDIA_VIDEO)
        else -> granted(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
}

// ───────────────────────── приложение ─────────────────────────

@Composable
private fun GalleryApp(vm: GalleryViewModel, light: Boolean) {
    val context = LocalContext.current
    var settingsOpen by remember { mutableStateOf(false) }

    // удаление фото с устройства: система сама показывает диалог подтверждения (Android 11+)
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
        if (it.resultCode == Activity.RESULT_OK) {
            vm.refresh()
            vm.refreshTrash()
        }
    }
    val deleteFromDevice: ((Photo) -> Unit)? = if (Build.VERSION.SDK_INT >= 30) {
        { photo ->
            val request = MediaStore.createTrashRequest(context.contentResolver, listOf(photo.uri), true)
            deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
        }
    } else null

    val deleteMany: ((List<Photo>) -> Unit)? = if (Build.VERSION.SDK_INT >= 30) {
        { list ->
            if (list.isNotEmpty()) {
                val request = MediaStore.createTrashRequest(context.contentResolver, list.map { it.uri }, true)
                deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            }
        }
    } else null
    val restoreMany: ((List<Photo>) -> Unit)? = if (Build.VERSION.SDK_INT >= 30) {
        { list ->
            val request = MediaStore.createTrashRequest(context.contentResolver, list.map { it.uri }, false)
            deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
        }
    } else null
    val eraseMany: ((List<Photo>) -> Unit)? = if (Build.VERSION.SDK_INT >= 30) {
        { list ->
            val request = MediaStore.createDeleteRequest(context.contentResolver, list.map { it.uri })
            deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
        }
    } else null
    var selecting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            val json = vm.backupJson()
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) } != null
                }.getOrDefault(false)
            }
            Toast.makeText(context, if (ok) "Копия сохранена" else "Не удалось сохранить файл", Toast.LENGTH_LONG).show()
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val text = withContext(Dispatchers.IO) {
                runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
            }
            val result = text?.let { vm.restoreBackup(it) }
            val msg = if (result == null) "Это не файл копии Galera" else "Восстановлено: коллекций ${result.first}, фото найдено ${result.second}"
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
        }
    }
    var hiddenUnlocked by remember { mutableStateOf(false) }
    var pinMode by remember { mutableStateOf(0) } // 0 — нет, 1 — создать PIN, 2 — ввести PIN

    var granted by remember { mutableStateOf(hasMediaAccess(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasMediaAccess(context)
        if (granted) vm.refresh()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        granted = hasMediaAccess(context)
        if (granted) vm.refresh()
    }

    if (!granted) {
        PermissionScreen { launcher.launch(mediaPermissions()) }
        return
    }

    val photos by vm.photos.collectAsState()
    val allPhotos by vm.allPhotos.collectAsState()
    val hiddenPhotos by vm.hiddenPhotos.collectAsState()
    val albums by vm.albums.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val meta by vm.meta.collectAsState()
    val viewerIds by vm.viewerIds.collectAsState()
    // теги по частоте использования: (название, сколько фото)
    val tagStats = remember(meta) {
        val counts = LinkedHashMap<String, Pair<String, Int>>()
        meta.values.forEach { m ->
            m.tags.forEach { t ->
                val key = t.lowercase()
                val old = counts[key]
                counts[key] = if (old == null) t to 1 else old.first to (old.second + 1)
            }
        }
        counts.values.sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first.lowercase() })
    }
    val tagNames = remember(tagStats) { tagStats.map { it.first } }
    val smartList = remember(photos, favorites, meta) { buildSmart(photos, favorites, meta) }
    val trashed by vm.trashed.collectAsState()
    val economy by vm.economy.collectAsState()
    val themeMode by vm.theme.collectAsState()
    val albumLayout by vm.albumLayout.collectAsState()
    val gridColumns by vm.gridColumns.collectAsState()
    val lowEnd = com.galera.app.ui.LocalLowEnd.current
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val lightRoutes = setOf("albums", "photos", "trash", "hidden", "duplicates", "smart/{key}")
    val barsLight = light && route in lightRoutes
    DisposableEffect(barsLight) {
        val activity = context as? ComponentActivity
        val style = if (barsLight) {
            SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
        } else {
            SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        }
        activity?.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        onDispose { }
    }
    val showBar = (route == "albums" || route == "photos") && !selecting

    Box(Modifier.fillMaxSize()) {
        NavHost(
            navController = nav,
            startDestination = "albums",
            enterTransition = { fadeIn(tween(280)) + scaleIn(tween(280), initialScale = 0.96f) },
            exitTransition = { fadeOut(tween(200)) },
            popEnterTransition = { fadeIn(tween(240)) },
            popExitTransition = { fadeOut(tween(220)) + scaleOut(tween(220), targetScale = 0.96f) },
        ) {

            composable("albums") {
                AlbumsScreen(
                    albums = albums,
                    photos = photos,
                    onOpen = { nav.navigate("album/$it") },
                    onCreate = { nav.navigate("create") },
                    onAddPhotos = { nav.navigate("add/$it") },
                    onSettings = { settingsOpen = true },
                    layout = albumLayout,
                    onLayout = vm::setAlbumLayout,
                    smart = smartList,
                    onSmart = { nav.navigate("smart/$it") },
                )
            }

            composable("photos") {
                PhotosScreen(
                    photos = photos,
                    favorites = favorites,
                    meta = meta,
                    popularTags = tagStats,
                    albums = albums,
                    columns = gridColumns,
                    onColumns = vm::setGridColumns,
                    onOpen = { list, index ->
                        vm.openList(list.map { it.id })
                        nav.navigate("viewer/list/$index")
                    },
                    onSelectingChange = { selecting = it },
                    onAddToAlbum = { ids, album ->
                        vm.addPhotos(album.id, ids)
                        Toast.makeText(context, "Добавлено в «${album.name}»: ${ids.size}", Toast.LENGTH_SHORT).show()
                    },
                    onNewAlbum = { ids, name ->
                        vm.createAlbum(name, ids, albums.size % Accents.size)
                        Toast.makeText(context, "Создана коллекция «$name»", Toast.LENGTH_SHORT).show()
                    },
                    onTagMany = { ids, tag ->
                        vm.addTagToMany(ids, tag)
                        Toast.makeText(context, "Тег добавлен: ${ids.size}", Toast.LENGTH_SHORT).show()
                    },
                    onFavoriteMany = { ids, fav -> vm.setFavorite(ids, fav) },
                    onHideMany = { ids ->
                        vm.hide(ids)
                        Toast.makeText(context, "Скрыто: ${ids.size}. Они в «Настройки → Скрытая папка»", Toast.LENGTH_LONG).show()
                    },
                    onDeleteMany = deleteMany,
                )
            }

            composable("create") {
                DarkScope {
                PickPhotosScreen(
                    title = "Новая коллекция",
                    showName = true,
                    confirmLabel = "Создать",
                    photos = photos,
                    onClose = { nav.popBackStack() },
                    onConfirm = { name, ids, accent ->
                        val id = vm.createAlbum(name, ids, accent)
                        nav.navigate("album/$id") { popUpTo("create") { inclusive = true } }
                    },
                )
            
                }
            }

            composable(
                "album/{id}",
                arguments = listOf(navArgument("id") { type = NavType.StringType }),
            ) { entry ->
                DarkScope {
                val id = entry.arguments?.getString("id").orEmpty()
                val album = albums.firstOrNull { it.id == id }
                if (album == null) {
                    // коллекцию удалили — выходим
                    LaunchedEffect(Unit) { nav.popBackStack() }
                } else {
                    val albumPhotos = remember(album, photos) {
                        val byId = photos.associateBy { it.id }
                        album.photoIds.mapNotNull { byId[it] }
                    }
                    AlbumScreen(
                        album = album,
                        photos = albumPhotos,
                        onBack = { nav.popBackStack() },
                        onOpenPhoto = { nav.navigate("viewer/$id/$it") },
                        onAddPhotos = { nav.navigate("add/$id") },
                        onRename = { vm.rename(id, it) },
                        onDelete = { vm.deleteAlbum(id) },
                        columns = gridColumns,
                        onColumns = vm::setGridColumns,
                        onCover = { vm.setCover(id, it) },
                    )
                }
            
                }
            }

            composable(
                "add/{id}",
                arguments = listOf(navArgument("id") { type = NavType.StringType }),
            ) { entry ->
                DarkScope {
                val id = entry.arguments?.getString("id").orEmpty()
                val album = albums.firstOrNull { it.id == id }
                val available = remember(album, photos) {
                    val existing = album?.photoIds?.toSet().orEmpty()
                    photos.filter { it.id !in existing }
                }
                PickPhotosScreen(
                    title = "Добавить фото",
                    showName = false,
                    confirmLabel = "Добавить",
                    photos = available,
                    onClose = { nav.popBackStack() },
                    onConfirm = { _, ids, _ ->
                        vm.addPhotos(id, ids)
                        nav.popBackStack()
                    },
                )
            
                }
            }

            composable(
                "smart/{key}",
                arguments = listOf(navArgument("key") { type = NavType.StringType }),
            ) { entry ->
                val key = entry.arguments?.getString("key").orEmpty()
                val item = smartList.firstOrNull { it.key == key }
                if (item == null) {
                    LaunchedEffect(Unit) { nav.popBackStack() }
                } else {
                    SimpleGridScreen(
                        title = item.title,
                        photos = item.photos,
                        columns = gridColumns,
                        onColumns = vm::setGridColumns,
                        onBack = { nav.popBackStack() },
                        onOpen = { list, index ->
                            vm.openList(list.map { it.id })
                            nav.navigate("viewer/list/$index")
                        },
                    )
                }
            }

            composable("hidden") {
                if (!hiddenUnlocked) {
                    LaunchedEffect(Unit) { nav.popBackStack() }
                } else {
                    HiddenScreen(
                        photos = hiddenPhotos,
                        columns = gridColumns,
                        onBack = {
                            hiddenUnlocked = false
                            nav.popBackStack()
                        },
                        onOpen = { list, index ->
                            vm.openList(list.map { it.id })
                            nav.navigate("viewer/hidden/$index")
                        },
                        onUnhide = vm::unhide,
                    )
                }
            }

            composable("duplicates") {
                val running by vm.dupRunning.collectAsState()
                val progress by vm.dupProgress.collectAsState()
                val groups by vm.dupGroups.collectAsState()
                DuplicatesScreen(
                    running = running,
                    progress = progress,
                    groups = groups,
                    alive = remember(photos) { photos.mapTo(HashSet()) { it.id } },
                    onScan = vm::scanDuplicates,
                    onBack = { nav.popBackStack() },
                    onTrash = deleteMany,
                )
            }

            composable("trash") {
                TrashScreen(
                    photos = trashed,
                    columns = gridColumns,
                    onBack = { nav.popBackStack() },
                    onRefresh = vm::refreshTrash,
                    onRestore = { restoreMany?.invoke(it) },
                    onDeleteForever = { eraseMany?.invoke(it) },
                )
            }

            composable(
                "edit/{id}",
                arguments = listOf(navArgument("id") { type = NavType.LongType }),
            ) { entry ->
                DarkScope {
                val pid = entry.arguments?.getLong("id") ?: -1L
                val target = photos.firstOrNull { it.id == pid }
                if (target == null) {
                    LaunchedEffect(Unit) { nav.popBackStack() }
                } else {
                    EditorScreen(
                        photo = target,
                        onClose = { nav.popBackStack() },
                        onSaved = {
                            vm.refresh()
                            nav.popBackStack()
                        },
                    )
                }
            
                }
            }

            composable(
                "viewer/{source}/{index}",
                arguments = listOf(
                    navArgument("source") { type = NavType.StringType },
                    navArgument("index") { type = NavType.IntType },
                ),
                // фото «вырастает» из плитки, на которую нажали
                enterTransition = {
                    if (lowEnd) fadeIn(tween(200))
                    else scaleIn(tween(340), initialScale = 0.2f, transformOrigin = Hero.origin) + fadeIn(tween(220))
                },
                popExitTransition = {
                    if (lowEnd) fadeOut(tween(180))
                    else scaleOut(tween(280), targetScale = 0.2f, transformOrigin = Hero.origin) + fadeOut(tween(240))
                },
            ) { entry ->
                DarkScope {
                val source = entry.arguments?.getString("source").orEmpty()
                val index = entry.arguments?.getInt("index") ?: 0
                when (source) {
                    "list" -> {
                        val list = remember(viewerIds, allPhotos) {
                            val byId = allPhotos.associateBy { it.id }
                            viewerIds.mapNotNull { byId[it] }
                        }
                        ViewerScreen(
                            photos = list,
                            startIndex = index,
                            favorites = favorites,
                            meta = meta,
                            popularTags = tagNames,
                            onBack = { nav.popBackStack() },
                            onToggleFavorite = vm::toggleFavorite,
                            onAddTag = vm::addTag,
                            onRemoveTag = vm::removeTag,
                            onNote = vm::setNote,
                            onDeleteFromDevice = deleteFromDevice,
                            onEdit = { nav.navigate("edit/${it.id}") },
                            onHide = {
                                vm.hide(listOf(it.id))
                                nav.popBackStack()
                            },
                        )
                    }
                    "hidden" -> {
                        ViewerScreen(
                            photos = hiddenPhotos,
                            startIndex = index,
                            favorites = favorites,
                            meta = meta,
                            popularTags = tagNames,
                            onBack = { nav.popBackStack() },
                            onToggleFavorite = vm::toggleFavorite,
                            onAddTag = vm::addTag,
                            onRemoveTag = vm::removeTag,
                            onNote = vm::setNote,
                            onHide = { vm.unhide(listOf(it.id)) },
                            hideLabel = "Вернуть из скрытых",
                        )
                    }
                    else -> {
                        val album = albums.firstOrNull { it.id == source }
                        val albumPhotos = remember(album, photos) {
                            val byId = photos.associateBy { it.id }
                            album?.photoIds?.mapNotNull { byId[it] }.orEmpty()
                        }
                        ViewerScreen(
                            photos = albumPhotos,
                            startIndex = index,
                            favorites = favorites,
                            meta = meta,
                            popularTags = tagNames,
                            onBack = { nav.popBackStack() },
                            onToggleFavorite = vm::toggleFavorite,
                            onAddTag = vm::addTag,
                            onRemoveTag = vm::removeTag,
                            onNote = vm::setNote,
                            onRemove = { vm.removePhoto(source, it.id) },
                            onHide = { vm.hide(listOf(it.id)) },
                            onDeleteFromDevice = deleteFromDevice,
                            onEdit = { nav.navigate("edit/${it.id}") },
                        )
                    }
                }
            
                }
            }
        }

        if (showBar) {
            BottomBar(
                current = if (route == "photos") 1 else 0,
                onSelect = { index ->
                    val dest = if (index == 0) "albums" else "photos"
                    if (dest != route) {
                        nav.navigate(dest) {
                            popUpTo("albums") { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                },
                onAdd = { nav.navigate("create") },
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }

    if (pinMode != 0) {
        PinDialog(
            creating = pinMode == 1,
            onDone = { pin ->
                val ok = if (pinMode == 1) {
                    vm.setPin(pin)
                    true
                } else vm.checkPin(pin)
                if (ok) {
                    pinMode = 0
                    hiddenUnlocked = true
                    nav.navigate("hidden")
                }
                ok
            },
            onDismiss = { pinMode = 0 },
        )
    }

    if (settingsOpen) {
        SettingsDialog(
            current = economy,
            onSelect = vm::setEconomy,
            columns = gridColumns,
            onColumns = vm::setGridColumns,
            theme = themeMode,
            onTheme = vm::setTheme,
            onDuplicates = { nav.navigate("duplicates") },
            onBackup = { backupLauncher.launch("galera-backup.json") },
            onRestore = { restoreLauncher.launch(arrayOf("*/*")) },
            onTrash = if (Build.VERSION.SDK_INT >= 30) ({ nav.navigate("trash") }) else null,
            onHidden = { pinMode = if (vm.hasPin()) 2 else 1 },
            onDismiss = { settingsOpen = false },
        )
    }
}

@Composable
private fun BottomBar(
    current: Int,
    onSelect: (Int) -> Unit,
    onAdd: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PillSwitch(count = 2, selected = current, onSelect = onSelect) { index, tint ->
            Icon(
                if (index == 0) Icons.Rounded.Collections else Icons.Rounded.PhotoLibrary,
                contentDescription = if (index == 0) "Коллекции" else "Все фото",
                tint = tint,
            )
        }
        Spacer(Modifier.weight(1f))
        Box(
            Modifier
                .size(62.dp)
                .clip(CircleShape)
                .background(LocalInk.current.ink)
                .clickable(onClick = onAdd),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Add, contentDescription = "Новая коллекция", tint = LocalInk.current.onInk, modifier = Modifier.size(30.dp))
        }
    }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CardFan(uris = emptyList())
        Spacer(Modifier.height(32.dp))
        Text(
            "Доступ к фотографиям",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Чтобы собирать фото в коллекции, разрешите доступ к галерее. Фото никуда не отправляются.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(28.dp))
        PrimaryPill("Разрешить доступ", onRequest)
    }
}
