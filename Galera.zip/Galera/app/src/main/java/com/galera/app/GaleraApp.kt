package com.galera.app

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.memory.MemoryCache
import com.galera.app.data.Device
import com.galera.app.data.Prefs

/** Настраивает загрузчик картинок: на слабых устройствах — меньше памяти, RGB_565, без fade. */
class GaleraApp : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader {
        val economy = Prefs(this).economy
        val low = when (economy) {
            1 -> true
            2 -> false
            else -> Device.isLowEnd(this)
        }
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(if (low) 0.12 else 0.25)
                    .build()
            }
            .allowRgb565(low)
            .crossfade(!low)
            .build()
    }
}
