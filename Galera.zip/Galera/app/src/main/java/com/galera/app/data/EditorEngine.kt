package com.galera.app.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

/** Параметры правки. */
data class Edit(
    val rotation: Int = 0, // в четвертях оборота
    val flipH: Boolean = false,
    val aspect: Int = 0, // 0 — оригинал
    val brightness: Float = 0f, // -1..1
    val contrast: Float = 1f, // 0.5..1.5
    val saturation: Float = 1f, // 0..2
    val filter: Int = 0,
) {
    val hasAdjustments get() = brightness != 0f || contrast != 1f || saturation != 1f
}

val FilterNames = listOf("Оригинал", "Ч/Б", "Сепия", "Тёплый", "Холодный", "Яркий", "Выцветший")
val AspectNames = listOf("Оригинал", "1:1", "4:3", "3:4", "16:9", "9:16")

object Editor {

    fun aspectValue(i: Int): Float? = when (i) {
        1 -> 1f
        2 -> 4f / 3f
        3 -> 3f / 4f
        4 -> 16f / 9f
        5 -> 9f / 16f
        else -> null
    }

    /** Загружает фото не крупнее maxSide по большей стороне, с учётом EXIF-поворота. */
    fun load(context: Context, uri: Uri, maxSide: Int): Bitmap? = runCatching {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = resolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
        }
        if (m.isIdentity) raw else Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
    }.getOrNull()

    fun transform(src: Bitmap, rotation: Int, flipH: Boolean): Bitmap {
        val r = ((rotation % 4) + 4) % 4
        if (r == 0 && !flipH) return src
        val m = Matrix()
        if (flipH) m.postScale(-1f, 1f)
        m.postRotate(90f * r)
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /** Центральная область нужных пропорций. */
    fun cropRect(w: Int, h: Int, aspect: Int): Rect {
        val ratio = aspectValue(aspect) ?: return Rect(0, 0, w, h)
        var cw = w
        var ch = (w / ratio).toInt()
        if (ch > h) {
            ch = h
            cw = (h * ratio).toInt()
        }
        cw = cw.coerceIn(1, w)
        ch = ch.coerceIn(1, h)
        val left = (w - cw) / 2
        val top = (h - ch) / 2
        return Rect(left, top, left + cw, top + ch)
    }

    private fun contrastBrightness(c: Float, b: Float): ColorMatrix {
        val t = 128f * (1f - c) + b * 100f
        return ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f,
            ),
        )
    }

    fun colorMatrix(e: Edit): ColorMatrix {
        val cm = ColorMatrix()
        when (e.filter) {
            1 -> cm.postConcat(ColorMatrix().apply { setSaturation(0f) })
            2 -> cm.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        0.393f, 0.769f, 0.189f, 0f, 0f,
                        0.349f, 0.686f, 0.168f, 0f, 0f,
                        0.272f, 0.534f, 0.131f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f,
                    ),
                ),
            )
            3 -> cm.postConcat(ColorMatrix().apply { setScale(1.10f, 1.0f, 0.88f, 1f) })
            4 -> cm.postConcat(ColorMatrix().apply { setScale(0.90f, 1.0f, 1.10f, 1f) })
            5 -> {
                cm.postConcat(ColorMatrix().apply { setSaturation(1.4f) })
                cm.postConcat(contrastBrightness(1.1f, 0f))
            }
            6 -> cm.postConcat(contrastBrightness(0.85f, 0.2f))
        }
        cm.postConcat(ColorMatrix().apply { setSaturation(e.saturation) })
        cm.postConcat(contrastBrightness(e.contrast, e.brightness))
        return cm
    }

    /** Итоговое изображение: поворот → обрезка → цвет. */
    fun render(context: Context, uri: Uri, e: Edit, maxSide: Int): Bitmap? {
        val base = load(context, uri, maxSide) ?: return null
        val t = transform(base, e.rotation, e.flipH)
        val r = cropRect(t.width, t.height, e.aspect)
        val out = Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(colorMatrix(e)) }
        Canvas(out).drawBitmap(t, r, Rect(0, 0, out.width, out.height), paint)
        return out
    }

    /** Сохраняет копию в Pictures/Galera. */
    fun save(context: Context, bitmap: Bitmap): Uri? = runCatching {
        val name = "Galera_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        }
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        if (Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Galera")
            values.put(MediaStore.Images.Media.IS_PENDING, 1)
            val uri = resolver.insert(collection, values) ?: return null
            resolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            uri
        } else {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Galera")
            dir.mkdirs()
            val file = File(dir, name)
            file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            @Suppress("DEPRECATION")
            values.put(MediaStore.Images.Media.DATA, file.absolutePath)
            resolver.insert(collection, values)
        }
    }.getOrNull()
}
